/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: u761161547_altoparque
-- ------------------------------------------------------
-- Server version	11.8.8-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `file` varchar(128) DEFAULT NULL,
  `body` mediumtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Corte de Pasto y Jardinería','corte-de-pasto-y-jardineria',NULL,NULL,'2022-10-25 05:10:58','2022-10-25 05:10:58'),
(2,'Desmalezado de Terrenos','desmalezado-de-terrenos',NULL,NULL,'2023-02-22 05:23:48','2023-02-22 05:23:48'),
(3,'Corte de Cercos y Enredaderas','corte-de-cercos-y-enredaderas',NULL,'Corte de Cercos y Enredaderas\r\nCorte de Cercos y Enredaderas\r\nCorte de Cercos y Enredaderas','2023-04-03 18:40:38','2023-04-03 18:40:38'),
(4,'Poda de Altura','poda-de-altura',NULL,NULL,'2023-10-08 05:22:54','2023-10-08 05:22:54'),
(5,'Corte de Pasto Con Tractor','corte-de-pasto-con-tractor',NULL,NULL,'2025-06-18 15:28:12','2025-06-18 15:28:12'),
(6,'Nivelado de Terreno','nivelado-de-terreno',NULL,NULL,'2026-07-07 14:38:04','2026-07-07 14:38:04');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gender` enum('Masculino','Femenino') NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `profession` varchar(255) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `body` text NOT NULL,
  `status` enum('PUBLISHED','DRAFT') NOT NULL DEFAULT 'DRAFT',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES
(1,'Femenino','Patricia','sofia@hotmail.com','Economista',3,6,'Muy buen servicio y dedicación!','PUBLISHED','2022-10-27 21:19:20','2022-10-31 02:32:38'),
(2,'Femenino','Carla','miadeluca2014@gmail.com','Docente',4,4,'Excelente trabajo. Quedé muy conforme','PUBLISHED','2022-11-04 22:55:21','2022-11-30 18:38:44'),
(4,'Femenino','Graciela Fabiana Bruscino','g.bruscino@simko.com.ar','Secretaria',8,6,'Execelente el trabajo de ustedes y personas muy amables.','PUBLISHED','2022-11-30 18:35:42','2022-11-30 18:39:02'),
(5,'Masculino','Leandro','ll_guevara@yahoo.com','Contador',4,11,'Excelente trabajo realizado. Muy buenas personas, educadas y por sobre todo MUY TRABAJADORAS. \r\nSON 100% recomendables  se los aseguro. Y van a todos lados!!!!','PUBLISHED','2022-12-03 20:57:30','2022-12-03 21:24:52'),
(7,'Masculino','Miguel kucharczuk','migel.celeste@hotmail.com','Empleado',18,2,'Muy Buena Atención y Responsabilidad','PUBLISHED','2022-12-12 14:51:20','2022-12-12 14:53:44'),
(8,'Masculino','Gastón','abastecimiento@pentaka.com','Responsable de Compras',3,5,'Hoy fue nuestro primer día del servicio que prestan, la verdad que fue excelente, cumplieron con lo acordado en el corte, limpieza y prolijidad. Gracias','PUBLISHED','2022-12-23 18:20:48','2022-12-23 18:22:07'),
(9,'Femenino','Laura','lufinocch@hotmail.com','Recursos humanos',14,6,'Buen servicio, eficiente y ordenado.','PUBLISHED','2022-12-24 05:23:42','2022-12-24 08:19:16'),
(11,'Femenino','Natalia','maga_404@hotmail.com','Independiente',13,11,'Excelente servicio brindado.\r\nTrato cordial y resolvieron todas mis dudas\r\nMuy recomendable','PUBLISHED','2022-12-29 15:29:23','2022-12-30 02:38:51'),
(12,'Femenino','Marisa','marisa1808@yahoo.com.ar','administrativa',18,8,'Muy buen servicio. Amabilidad, prolijidad.','PUBLISHED','2023-01-05 20:50:09','2023-01-05 23:57:56'),
(13,'Femenino','Florencia Fernandez','ffernandez@vogeargentina.com.ar','Encargada de local',26,4,'Excelente servicio, Jofret fue muy amable e hizo un trabajo mejor de lo esperado. Gracias, volveré a contactarlo','PUBLISHED','2023-01-06 01:11:08','2023-01-06 01:17:48'),
(14,'Masculino','Ricardo','ricardosidoti@yahoo.com','Ingeniero',5,9,'Muy buen servicio, muy cordial, excelente atencion.','PUBLISHED','2023-01-10 23:45:28','2023-01-11 05:33:11'),
(15,'Masculino','Matias Ezequiel Roquel','mroquel@dinatecnica.com.ar','Gerente de Compras',30,9,'Excelente servicio, quedamos muy conformes con la visita y el tratamiento que le dieron a las plantas. Los esperamos para el próximo mantenimiento.','PUBLISHED','2023-01-30 21:36:41','2023-01-30 21:46:00'),
(16,'Masculino','Fidel','torresfideloctavio@gmail.com','Administrador',19,7,'Excelente servicio. Muy recomendable','PUBLISHED','2023-02-22 01:48:02','2023-02-22 01:48:50'),
(17,'Masculino','Ernesto Juan','informes@casasanignacio.com.ar','Administración',0,0,'Excelente servicio. personal muy responsable. Cumplieron con todo lo pactado..y un poco más. Muy buen trato con el cliente','PUBLISHED','2023-03-08 20:14:23','2023-03-09 00:23:50'),
(18,'Femenino','Sandra de Virzi','sandra.alonvir@gmail.com','Ama de casa',21,7,'Excelente podado de enredaderas y muy prolijo todo embolsado y puesto en la vereda!! Gracias!!!¡','PUBLISHED','2023-04-03 16:52:54','2023-04-03 17:11:31'),
(19,'Femenino','Belen','belenladaga@gmail.com','Diseñadora',0,0,'Excelente servicio! Mi jardín estaba imposible y ahora puedo disfrutarlo. Jofret es súper amable y prolijo. 100% recomiendo.','PUBLISHED','2023-04-22 18:22:34','2023-04-23 21:01:33'),
(20,'Masculino','Guillermo','gpascual.1004@gmail.com','Analista',10,4,'Excelente Servicio','PUBLISHED','2023-04-27 17:18:47','2023-04-28 21:03:11'),
(21,'Masculino','MARCOS','mar.and.per.med@gmail.com','Analista de Sistemas',21,9,'Excelente trabajo!','PUBLISHED','2023-09-15 17:05:49','2023-09-15 18:29:13'),
(22,'Masculino','Jose','reyesja90@gmail.com','Docente',30,5,'Excelente servicio pero más importante que eso la calidez humana de quien lo hace.','PUBLISHED','2023-09-15 18:37:20','2023-09-15 18:44:57'),
(25,'Femenino','Josefina','gecea13run@gmail.com','Jubilada',19,3,'Excelente servicio. Responsables, detallistas y además cumplieron con lo pactado. Super recomendable.','PUBLISHED','2023-09-21 04:04:06','2023-09-21 16:49:57'),
(26,'Femenino','Graciela','gracielamolina63@gmail.com','Empleada',1,10,'Muy buena gente y muy buena atención. Excelente servicio ! Vuelven seguro. Gracias','PUBLISHED','2023-09-29 06:48:03','2023-09-29 07:31:16'),
(27,'Femenino','Norma Gloria Damianoff','cateringnorma@hotmail.com','Ama de casa',8,8,'Excelente trabajo como siempre, prolijos, rápidos, muy amables.\nRecomendable 100 por ciento','PUBLISHED','2023-10-09 00:06:40','2023-10-09 00:08:08'),
(29,'Masculino','Tomas','tomas.steimez@gmail.com','Empleado',16,12,'Muy buen trabajo y jofre siempre un trato muy cordial muy agradecido','PUBLISHED','2023-10-15 02:20:22','2023-10-15 03:05:18'),
(30,'Masculino','Xabier','javigibson@gmail.com','Diseñador',25,10,'Excelente servicio, atención y trato. Volveré a repetir seguro!','PUBLISHED','2024-01-22 19:40:08','2024-01-23 04:21:45'),
(31,'Femenino','Juan carlos barcos','juancarlosbarcos1963@gmail.com','Empleado de seguridad privada',4,4,'Muy conforme, gente muy responsable','PUBLISHED','2024-01-23 00:13:15','2024-01-23 04:21:24'),
(32,'Femenino','Nancy','nancyalvarezmac@gmail.com','Entrenadora',3,6,'Exelente servicio y atención','PUBLISHED','2024-01-28 03:22:48','2024-01-30 14:03:55'),
(33,'Femenino','Mariana Prandi','marianaprandi@gmail.com','Traductora',14,8,'Muy buena atención y servicio. Excelente trabajo','PUBLISHED','2024-01-30 18:20:06','2024-01-30 19:27:27'),
(34,'Femenino','Karina','karinaalejandra_@hotmail.com','Vendedora',6,1,'Excelente todo !! Los encontré por Google y en menos de 24 hs ya estaban trabajando en casa. Muy recomendables y confiables. Gracias por la buena atención y el trabajo profesional ! Quedamos muy conformes!!','PUBLISHED','2024-02-27 22:08:59','2024-02-27 22:10:08'),
(35,'Masculino','Juan Carlos','jcr564@hotmail.com','Jubilado',24,6,'Los contacte luego de varios fracasos con otros jardineros, fueron cumplidores con lo pactado, fecha y hora, realizaron poda de arbol, de ligustre, corte de césped, luego realizaron la limpieza total del jardín embolsando y retirando los restos, quede muy conforme con el trabajo realizado, los contrato para el mantenimiento.','DRAFT','2026-03-05 17:27:49','2026-03-05 17:27:49'),
(36,'Femenino','Patricia Dominguez','patri1612@hotmail.com','Empleada Administrativa',29,6,'Excelente servicio, muy prolijos y ordenados, super recomendables👍','DRAFT','2026-07-06 19:48:24','2026-07-06 19:48:24'),
(37,'Femenino','Patricia Dominguez','patri1612@hotmail.com','Empleada Administrativa',29,6,'Excelente servicio, muy prolijos y ordenados, super recomendables👍','DRAFT','2026-07-06 19:48:46','2026-07-06 19:48:46');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `images_slug_unique` (`slug`),
  KEY `images_user_id_foreign` (`user_id`),
  KEY `images_post_id_foreign` (`post_id`),
  CONSTRAINT `images_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `images_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=276 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES
(3,1,2,'servicio de corte de pesto en del viso','servicio-de-corte-de-pesto-en-del-viso','https://serviciodejardineria.com.ar/image/6s8NW3xnER79hznrOxsdsWavjbk7pCnN7ZuvH6tm.jpg','2022-10-31 03:10:25','2022-10-31 03:10:26'),
(4,1,1,'servicio de corte de pasto en beccar','servicio-de-corte-de-pasto-en-beccar','https://serviciodejardineria.com.ar/image/vHxalpJ7FxomXEYBSqFSRl1qdZ742RXvXxa2pT8f.jpg','2022-10-31 03:20:16','2022-10-31 03:20:16'),
(5,1,3,'mantenimiento de jardiín en empresa sinko','mantenimiento-de-jardiin-en-empresa-sinko','https://serviciodejardineria.com.ar/image/lE3PNQnMnpEPbz4ws3uMfU02C4MaQLEtjKF4TA1h.jpg','2022-11-06 04:27:58','2022-11-06 04:27:59'),
(7,1,4,'Servicio de Corte de Pasto en Liniers','servicio-de-corte-de-pasto-en-liniers','https://serviciodejardineria.com.ar/image/y3Ahww8uiwlqvHxgme6wwOoktiZBF47FQqBOXbyp.jpg','2022-12-04 01:47:20','2022-12-04 01:47:20'),
(10,1,5,'Servicio de Corte de Pasto en Don Torcuato','servicio-de-corte-de-pasto-en-don-torcuato','https://serviciodejardineria.com.ar/image/MGOIh2nvckiO6a4Vy0mAOukgRn2GmhUyAkto98PL.jpg','2022-12-24 00:53:12','2022-12-24 00:53:13'),
(11,1,5,'Servicio de Corte de Pasto en DonTorcuato','servicio-de-corte-de-pasto-en-dontorcuato','https://serviciodejardineria.com.ar/image/L1PXHhI6IiGH8Y8hY8w4phLeSNqvZ0W5TLa0twGX.jpg','2023-02-09 03:38:19','2023-02-09 03:38:20'),
(12,1,5,'servicio de corte de jardneria en don torcuato','servicio-de-corte-de-jardneria-en-don-torcuato','https://serviciodejardineria.com.ar/image/aVDMJN5ETSdJj7kkyswU8g6Lxy7vLxkIqhw5Jmym.jpg','2023-02-09 03:39:57','2023-02-09 03:39:57'),
(13,1,4,'Corte de Pasto en Liniers','corte-de-pasto-en-liniers','https://serviciodejardineria.com.ar/image/I9wpplQ4xRLaS44oOtAbJtF2WuEsoOMfR60HFqFm.jpg','2023-02-09 04:34:36','2023-02-09 04:34:36'),
(14,1,4,'Servicio de Corte de Pasto','servicio-de-corte-de-pasto','https://serviciodejardineria.com.ar/image/htOQmMwSLrPtfTKb98KDVyA8mbjj7cXYNe9V4522.jpg','2023-02-09 04:36:43','2023-02-09 04:36:43'),
(15,1,4,'Servicio de Corte Pasto  Liniers','servicio-de-corte-pasto-liniers','https://serviciodejardineria.com.ar/image/1NgRYWqBtVyStnaY1jKn6tIF3P9Y1atCBhGuqG65.jpg','2023-02-09 04:37:38','2023-02-09 04:37:38'),
(16,1,4,'corte de pasto','corte-de-pasto','https://serviciodejardineria.com.ar/image/1IZoLnAMpwCoI73Rh2r29OYZOFDiD3oWHIfm9mrY.jpg','2023-02-09 04:40:05','2023-02-09 04:40:05'),
(17,1,3,'servicio de mantenimiento de jard{in de san mart{in','servicio-de-mantenimiento-de-jard-in-de-san-mart-in','https://serviciodejardineria.com.ar/image/ddcqcuPWXPwQAYtVojETPw7aLMCGdzOK1Ux2D9px.jpg','2023-02-09 04:44:00','2023-02-09 04:44:00'),
(18,1,3,'mantenimiento de jardin en san martin','mantenimiento-de-jardin-en-san-martin','https://serviciodejardineria.com.ar/image/BuQZ3nal5EmB7TZRQWcLAw14Tg36U7R50OT1nG3c.jpg','2023-02-09 04:46:18','2023-02-09 04:46:18'),
(19,1,3,'jardineros','jardineros','https://serviciodejardineria.com.ar/image/XxxB8pF2p47MStvyKWsJL0FX4u0fbbWswG9pjwae.jpg','2023-02-09 04:48:05','2023-02-09 04:48:05'),
(20,1,2,'corte de c{esped en del viso','corte-de-c-esped-en-del-viso','https://serviciodejardineria.com.ar/image/j8x84RaWrvic9AcgE9YkWjKNNoHsVapQQKAgIzef.jpg','2023-02-09 06:15:57','2023-02-09 06:15:57'),
(22,1,2,'servicio de corte de pasto del viso','servicio-de-corte-de-pasto-del-viso','https://serviciodejardineria.com.ar/image/ZXQp9ZxeR7tuJQgkukGPE6TvvuMMotrR663sHecl.jpg','2023-02-09 06:20:28','2023-02-09 06:20:29'),
(23,1,1,'servicio de corte de pastoen beccar','servicio-de-corte-de-pastoen-beccar','https://serviciodejardineria.com.ar/image/OZ91ieDJIvI6WNDvWE8BwHzeSL7WRGTdsjIn220h.jpg','2023-02-09 06:23:43','2023-02-09 06:23:44'),
(24,1,1,'servicio de corte de pasto en beccar buenos aires','servicio-de-corte-de-pasto-en-beccar-buenos-aires','https://serviciodejardineria.com.ar/image/joGRVuN0Gan40rSbEGDvFfE8eHv4cGG9ZMGvpyWt.jpg','2023-02-09 06:25:23','2023-02-09 06:25:24'),
(25,1,6,'servicio de jardineria','servicio-de-jardineria','https://serviciodejardineria.com.ar/image/ZcPqDjmSPdMn0jxm8cDXCIpsdD99FGIhZnNwFkeg.jpg','2023-02-10 14:59:27','2023-02-10 14:59:27'),
(26,1,6,'jardineria','jardineria','https://serviciodejardineria.com.ar/image/d1uF7G5ULqz9AiwAEHpTNMuGz8fMzpWoBrYTiqBR.jpg','2023-02-10 15:01:28','2023-02-10 15:01:28'),
(27,1,6,'jardineria mantenimiento','jardineria-mantenimiento','https://serviciodejardineria.com.ar/image/OtGnz4e0CkHHkGc6Fb0EsVfQ312TMlV7PwdVxk9A.jpg','2023-02-10 15:01:45','2023-02-10 15:01:45'),
(28,1,6,'mantenimeinto de parque','mantenimeinto-de-parque','https://serviciodejardineria.com.ar/image/HWFu5os6a6U3EJACHu6tB4A5HYX4wYZo0SAHqbmE.jpg','2023-02-10 15:02:07','2023-02-10 15:02:07'),
(29,1,6,'servicio jardineros','servicio-jardineros','https://serviciodejardineria.com.ar/image/DzWuYPKJuZvp9qvBE7cso7fLY4WwuyQ4QG43zoW4.jpg','2023-02-10 15:02:35','2023-02-10 15:02:35'),
(35,1,8,'Servicio de Jardineria en Beccar','servicio-de-jardineria-en-beccar','https://serviciodejardineria.com.ar/image/q5GFQkgOf00iQ33DtwJVWxs144QqW35Y8TNoz2lL.jpg','2023-02-17 03:53:22','2023-02-17 03:53:22'),
(36,1,8,'Servicio de Jardineria en Beccar2','servicio-de-jardineria-en-beccar2','https://serviciodejardineria.com.ar/image/v6FYr18ryuAEXRAertuUEGDfTtfRez92RGIcjodv.jpg','2023-02-17 03:53:56','2023-02-17 03:53:56'),
(37,1,8,'Servicio de Jardineria en Beccar3','servicio-de-jardineria-en-beccar3','https://serviciodejardineria.com.ar/image/KhT8C1C4hCnZ4PEvaJnOLrlAgEer11bP8E9452vk.jpg','2023-02-17 03:54:16','2023-02-17 03:54:16'),
(38,1,8,'Servicio de Jardineria en Beccar4','servicio-de-jardineria-en-beccar4','https://serviciodejardineria.com.ar/image/Of2hZEFuOvSyZjwkUsXXQAaaz79Bn3bw87sD8Xp4.jpg','2023-02-17 03:54:41','2023-02-17 03:54:41'),
(39,1,8,'Servicio de Jardineria en Beccar 4','servicio-de-jardineria-en-beccar-4','https://serviciodejardineria.com.ar/image/WwB1hTpYp27cWbcH0UACXjCoLlU8Cpw8be7h7win.jpg','2023-02-17 03:55:07','2023-02-17 03:55:07'),
(40,1,9,'desmalezado de terrenos','desmalezado-de-terrenos','https://serviciodejardineria.com.ar/image/cXnX5idFG2psxPz6T1hS1LFW4emTabbtNa8uFu0Q.jpg','2023-02-22 05:34:27','2023-02-22 05:34:28'),
(41,1,9,'demalezados','demalezados','https://serviciodejardineria.com.ar/image/qr0zlTRqrYRjIxgCKv2kqXvuLK48IMXx8S6OepNl.jpg','2023-02-22 05:40:22','2023-02-22 05:40:22'),
(42,1,9,'desmalezados','desmalezados','https://serviciodejardineria.com.ar/image/svkYRhmvGu8zx5qv2VFFyhX94XcVdyedLHL2V2oX.jpg','2023-02-22 05:45:28','2023-02-22 05:45:28'),
(43,1,9,'desmalezado de terreno','desmalezado-de-terreno','https://serviciodejardineria.com.ar/image/FAJ0T379FjgpWDcw9qhOD8ZeReiLIXSOWGCKqrCD.jpg','2023-02-22 05:49:51','2023-02-22 05:49:51'),
(44,1,9,'desmalezado terreno','desmalezado-terreno','https://serviciodejardineria.com.ar/image/SMTG4TppQpj5UjQ5mLoIhSNhlCtt8XaDxk0faWnF.jpg','2023-02-22 05:52:56','2023-02-22 05:52:56'),
(45,1,9,'demalezado de terrenos1','demalezado-de-terrenos1','https://serviciodejardineria.com.ar/image/JaZS1Ld9Sf2N5TAGyGWASr0oceK85HiOjDXp9Gft.jpg','2023-02-22 05:56:49','2023-02-22 05:56:49'),
(46,1,9,'limpieza de terreno','limpieza-de-terreno','https://serviciodejardineria.com.ar/image/M9TvwZS4PcefZO5TnJwRZgUIhUTe1qj4RwqZ5ZMn.jpg','2023-02-22 06:00:51','2023-02-22 06:00:52'),
(47,1,9,'terrenos desmalezado','terrenos-desmalezado','https://serviciodejardineria.com.ar/image/nptiCGnmGkn4d2Az1eCx5Is4SBEq5GoJyTTxORmW.jpg','2023-02-22 06:04:43','2023-02-22 06:04:43'),
(48,1,9,'desmalezado de terrenos 01','desmalezado-de-terrenos-01','https://serviciodejardineria.com.ar/image/JmTZeAz6ttSNfos2cKnhDdGNPbtvxHwR1R5x7mfJ.jpg','2023-02-22 06:07:44','2023-02-22 06:07:44'),
(49,1,9,'desmalezado de terrenos 03','desmalezado-de-terrenos-03','https://serviciodejardineria.com.ar/image/0Qjrw3wjD2YCxLIJV36rdSXpGO7p4FiztIK1rtVH.jpg','2023-02-22 06:14:28','2023-02-22 06:14:28'),
(50,1,10,'Limpieza de vereda en vicente lopez','limpieza-de-vereda-en-vicente-lopez','https://serviciodejardineria.com.ar/image/mjyeWdcayuVqBoBVEvGxY23PVrcfNbSOwIPbQKG7.jpg','2023-02-24 04:16:39','2023-02-24 04:16:40'),
(51,1,10,'Limpieza de Vereda en Vicente López 1','limpieza-de-vereda-en-vicente-lopez-1','https://serviciodejardineria.com.ar/image/omHsFllFS3ruup7xJllSLAhEPSvSmKd5zg0pWwwV.jpg','2023-02-24 04:17:21','2023-02-24 04:17:21'),
(53,1,10,'Limpieza de Vereda en Vicente López 2','limpieza-de-vereda-en-vicente-lopez-2','https://serviciodejardineria.com.ar/image/3xL8ut3VDeRGxR9BtmuOaieXkTFFCnO5xnLieyp5.jpg','2023-02-24 04:18:01','2023-02-24 04:18:01'),
(54,1,10,'Limpieza de Vereda en Vicente López 3','limpieza-de-vereda-en-vicente-lopez-3','https://serviciodejardineria.com.ar/image/PCH09c7vowqhSRW9uypBSzoya4Ybym8yELMwtECR.jpg','2023-02-24 04:18:18','2023-02-24 04:18:18'),
(55,1,11,'corte de cerco','corte-de-cerco','https://serviciodejardineria.com.ar/image/wkBcROssXfFBBIIEOuoBoup9srZEcF65NL1vdlPY.jpg','2023-04-03 18:48:20','2023-04-03 18:48:20'),
(56,1,11,'corte de cerco-1','corte-de-cerco-1','https://serviciodejardineria.com.ar/image/bzvX8YkKmUS8Dy6c0xY4n027BCWv45gjYQR718Iu.jpg','2023-04-03 18:51:04','2023-04-03 18:51:04'),
(57,1,11,'corte de cerco-2','corte-de-cerco-2','https://serviciodejardineria.com.ar/image/0LoOVPjRTRaEDRCM5NkH09hiBpgDcEewCSLXEb2B.jpg','2023-04-03 18:53:18','2023-04-03 18:53:18'),
(58,1,11,'corte de cerco-3','corte-de-cerco-3','https://serviciodejardineria.com.ar/image/hKMX4aa3w7wk0zXneyCUerZfHjHJXgBvHCuXGthC.jpg','2023-04-03 18:54:38','2023-04-03 18:54:38'),
(59,1,11,'corte de cerco-4','corte-de-cerco-4','https://serviciodejardineria.com.ar/image/UmNCta7GyTHhefAApHqfr1TBSJLrjLN4DG2eTBtD.jpg','2023-04-03 18:55:38','2023-04-03 18:55:38'),
(60,1,11,'corte de cerco-5','corte-de-cerco-5','https://serviciodejardineria.com.ar/image/3WRYEJWb7UvROgz98V43JYTjyg8tfvIz8IpUPNW1.jpg','2023-04-03 18:57:02','2023-04-03 18:57:02'),
(61,1,11,'corte de cerco-6','corte-de-cerco-6','https://serviciodejardineria.com.ar/image/rK8bPenrj4Vzrjocpy04WOlJi2rVNV1ue1hQ3yCJ.jpg','2023-04-03 18:58:28','2023-04-03 18:58:28'),
(62,1,11,'corte de cerco-7','corte-de-cerco-7','https://serviciodejardineria.com.ar/image/qtrWogt78p97hWzEAr6DaRb6lxI8AuF9I6bfWH2J.jpg','2023-04-03 18:59:42','2023-04-03 18:59:42'),
(65,1,12,'Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba','https://serviciodejardineria.com.ar/image/3bo7GP43MHEMjGd3cBYAonyjXKhMkjjM9NQHf4Ol.jpg','2023-04-15 03:17:41','2023-04-15 03:17:41'),
(66,1,12,'Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA 2','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba-2','https://serviciodejardineria.com.ar/image/I3KPhf4E0mWddM8T5Xxto7hsIpDmelmDeC5fLLfi.jpg','2023-04-15 03:22:05','2023-04-15 03:22:05'),
(67,1,12,'Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA 3','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba-3','https://serviciodejardineria.com.ar/image/Kbu3mfCmAy14RGo7ZsJgI3zTjbbmENrC6gYX8JBT.jpg','2023-04-15 03:23:30','2023-04-15 03:23:30'),
(68,1,12,'Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA 4','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba-4','https://serviciodejardineria.com.ar/image/Vu1IqpDTexq7d2Larw6iwe6L2I7Mh97OZDMOO7rh.jpg','2023-04-15 03:29:47','2023-04-15 03:29:47'),
(69,1,12,'Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA 5','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba-5','https://serviciodejardineria.com.ar/image/eoUyrVUd5nKDJUSaGWOEMpLtuXlaIo7S21YrITui.jpg','2023-04-15 03:33:16','2023-04-15 03:33:16'),
(70,1,12,'Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA 6','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba-6','https://serviciodejardineria.com.ar/image/0ExvgvRXZVmbfe4wxZAWaNMQYWx4nxEfFBbpPvK6.jpg','2023-04-15 03:46:49','2023-04-15 03:46:49'),
(71,1,12,'Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA 7','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba-7','https://serviciodejardineria.com.ar/image/EbmShtQGXS2G49DADYpsZRMr4pWijW3SintC6Bro.jpg','2023-04-15 03:51:53','2023-04-15 03:51:53'),
(72,1,12,'Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA 8','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba-8','https://serviciodejardineria.com.ar/image/lYP7yEM7G89h4h8FFbLKnTxusCLMV9iF9yftlkbr.jpg','2023-04-15 03:53:42','2023-04-15 03:53:42'),
(75,1,13,'Servicio de Desmalezado de Terreno en San Martín - San Andrés','servicio-de-desmalezado-de-terreno-en-san-martin-san-andres','https://serviciodejardineria.com.ar/image/8xxNgreC2Kdtg9QYiwhi1nIWsumvGWFw9m406SMU.jpg','2023-09-07 15:32:06','2023-09-07 15:32:06'),
(76,1,13,'Servicio de Desmalezado de Terreno en San Martín - San Andrés 1','servicio-de-desmalezado-de-terreno-en-san-martin-san-andres-1','https://serviciodejardineria.com.ar/image/PXOEXBohobLJgx0fwsyne7RbHndt5ZIcce0e13eV.jpg','2023-09-07 15:37:55','2023-09-07 15:37:55'),
(77,1,13,'Servicio de Desmalezado de Terreno en San Martín - San Andrés2','servicio-de-desmalezado-de-terreno-en-san-martin-san-andres2','https://serviciodejardineria.com.ar/image/xNOQi3OnOhzy9ghuNjPIl47iExE8NRBUhjv15yzZ.jpg','2023-09-07 15:42:40','2023-09-07 15:42:40'),
(78,1,13,'Servicio de Desmalezado de Terreno en San Martín - San Andrés3','servicio-de-desmalezado-de-terreno-en-san-martin-san-andres3','https://serviciodejardineria.com.ar/image/SfYOSbDycCNXXAe474KBFW7jAyKqhFs96GSs7hgH.jpg','2023-09-07 15:45:49','2023-09-07 15:45:49'),
(79,1,13,'Servicio de Desmalezado de Terreno en San Martín - San Andrés 4','servicio-de-desmalezado-de-terreno-en-san-martin-san-andres-4','https://serviciodejardineria.com.ar/image/QjFWcPlkznOlIqDXeDfMJ6jOJWuTEjkKXHbeJRcs.jpg','2023-09-07 15:50:13','2023-09-07 15:50:13'),
(80,1,13,'Servicio de Desmalezado de Terreno en San Martín - San Andrés 5','servicio-de-desmalezado-de-terreno-en-san-martin-san-andres-5','https://serviciodejardineria.com.ar/image/CfCSFTIhfEvLu8sf8q69M4N0s95l8XQekWv9ETl0.jpg','2023-09-07 15:56:38','2023-09-07 15:56:38'),
(81,1,14,'servicio de corte de pasto en alberti','servicio-de-corte-de-pasto-en-alberti','https://serviciodejardineria.com.ar/image/D2TnFNkKPdri6XbxpysYFzkLFIcvsH91K65n0AYl.jpg','2023-09-15 15:23:57','2023-09-15 15:23:57'),
(82,1,14,'Servicio de Corte de Pasto en Alberti-2','servicio-de-corte-de-pasto-en-alberti-2','https://serviciodejardineria.com.ar/image/2g0UzX7dm8mL4sromVwRCIQOSP4fIWvgluTS6oXQ.jpg','2023-09-15 15:34:07','2023-09-15 15:34:07'),
(83,1,14,'Servicio de Corte de Pasto en Alberti-3','servicio-de-corte-de-pasto-en-alberti-3','https://serviciodejardineria.com.ar/image/OIEa7Iefh8fUq57Tl9EsTeyPQYqOiLIKGxX7dvse.jpg','2023-09-15 15:34:34','2023-09-15 15:34:34'),
(84,1,14,'Servicio de Corte de Pasto en Alberti-4','servicio-de-corte-de-pasto-en-alberti-4','https://serviciodejardineria.com.ar/image/vjzZPUb8e46iKDo4F0SFBSyLFy8QV5J3XiG6Hq3V.jpg','2023-09-15 15:34:52','2023-09-15 15:34:52'),
(85,1,14,'Servicio de Corte de Pasto en Alberti-5','servicio-de-corte-de-pasto-en-alberti-5','https://serviciodejardineria.com.ar/image/hpVYkZcEjD4g0M7BKZ8pXnomfIg0ZC86TzZrT4yU.jpg','2023-09-15 15:35:03','2023-09-15 15:35:03'),
(86,1,14,'Servicio de Corte de Pasto en Alberti-6','servicio-de-corte-de-pasto-en-alberti-6','https://serviciodejardineria.com.ar/image/bWAOvGlJhCZBHlebkV9Mb2jt70WvIRYgWDVsISkZ.jpg','2023-09-15 15:35:19','2023-09-15 15:35:19'),
(87,1,14,'Servicio de Corte de Pasto en Alberti-7','servicio-de-corte-de-pasto-en-alberti-7','https://serviciodejardineria.com.ar/image/86Z22xEVCELWsi6gCfCwKD1535CQAPHROECBT0j4.jpg','2023-09-15 15:35:35','2023-09-15 15:35:35'),
(89,1,15,'servicio de corte de pasto en san fernando buenos aires','servicio-de-corte-de-pasto-en-san-fernando-buenos-aires','https://serviciodejardineria.com.ar/image/JkNouggFZyBvwg9Ukz132RuvtRCb22iwPb4nB0e9.jpg','2023-09-21 17:53:33','2023-09-21 17:53:33'),
(90,1,15,'servicio de corte de pasto en san fernando2','servicio-de-corte-de-pasto-en-san-fernando2','https://serviciodejardineria.com.ar/image/u5xDLszG922zGUfA6m9Epyg9iYNh1awh8b8ChOzt.jpg','2023-09-21 17:57:00','2023-09-21 17:57:00'),
(91,1,15,'servicio de corte de pasto en san fernando3','servicio-de-corte-de-pasto-en-san-fernando3','https://serviciodejardineria.com.ar/image/EwNKBvV5xmY34l9xv81rHXpSw3fcdKw78Z6CIW03.jpg','2023-09-21 17:58:53','2023-09-21 17:58:53'),
(93,1,15,'servicio de corte de pasto en san fernando4','servicio-de-corte-de-pasto-en-san-fernando4','https://serviciodejardineria.com.ar/image/VONGYUOhGm4a9R3PLj9QIwNrJLHghNHoF8uJvxVB.jpg','2023-09-21 18:00:31','2023-09-21 18:00:31'),
(94,1,15,'servicio de corte de pasto en san fernando5','servicio-de-corte-de-pasto-en-san-fernando5','https://serviciodejardineria.com.ar/image/RXpRToVu1lTaTEwJTLd4ofOJprquhW58atZOX4yj.jpg','2023-09-21 18:02:51','2023-09-21 18:02:51'),
(95,1,15,'servicio de corte de pasto en san fernando6','servicio-de-corte-de-pasto-en-san-fernando6','https://serviciodejardineria.com.ar/image/LDYTSZikG0m7rHf5poFZ2v5xDyd2pCJOpP7qteoO.jpg','2023-09-21 18:04:08','2023-09-21 18:04:08'),
(96,1,15,'servicio de corte de pasto en san fernando7','servicio-de-corte-de-pasto-en-san-fernando7','https://serviciodejardineria.com.ar/image/9fZJMMZkC20xEetk3bAoKCpB994WCpGnVVakeaYA.jpg','2023-09-21 18:05:49','2023-09-21 18:05:49'),
(97,1,15,'servicio de corte de pasto en san fernando8','servicio-de-corte-de-pasto-en-san-fernando8','https://serviciodejardineria.com.ar/image/3btceEkJ4HiiWN7668XQvYPOAOxJpYiQjZwL1duq.jpg','2023-09-21 18:06:54','2023-09-21 18:06:54'),
(98,1,15,'servicio de corte de pasto en san fernando9','servicio-de-corte-de-pasto-en-san-fernando9','https://serviciodejardineria.com.ar/image/D1tlD5gmVqmE7Ey2D6NLQXnm65nKOwyuckewiQ0h.jpg','2023-09-21 18:07:55','2023-09-21 18:07:55'),
(99,1,15,'servicio de corte de pasto en san fernando10','servicio-de-corte-de-pasto-en-san-fernando10','https://serviciodejardineria.com.ar/image/RhbR1yTZ73iEIwesvhXIf1NEBfXP1GTpwldr1jbf.jpg','2023-09-21 18:09:45','2023-09-21 18:09:45'),
(100,1,16,'Servicio de Corte de Pasto y Limpieza en Ingeniero Maschwitz','servicio-de-corte-de-pasto-y-limpieza-en-ingeniero-maschwitz','https://serviciodejardineria.com.ar/image/P1ABHYyloCMufDbNKYxR3ITuJPVsu3WdD9ht69wu.jpg','2023-09-28 19:26:37','2023-09-28 19:26:37'),
(101,1,16,'Servicio de Corte de Pasto y Limpieza en Ingeniero Maschwitz-2','servicio-de-corte-de-pasto-y-limpieza-en-ingeniero-maschwitz-2','https://serviciodejardineria.com.ar/image/UKFTeHCRiCgJ65L5gJUGsuOsEWyFHZNgxer1447N.jpg','2023-09-28 19:30:08','2023-09-28 19:30:08'),
(102,1,16,'Servicio de Corte de Pasto y Limpieza en Ingeniero Maschwitz-3','servicio-de-corte-de-pasto-y-limpieza-en-ingeniero-maschwitz-3','https://serviciodejardineria.com.ar/image/VCQgqPsnI3XzGu6xFtLaWQ5p663BBOyJHtmwduJS.jpg','2023-09-28 19:32:13','2023-09-28 19:32:13'),
(103,1,16,'Servicio de Corte de Pasto y Limpieza en Ingeniero Maschwitz-4','servicio-de-corte-de-pasto-y-limpieza-en-ingeniero-maschwitz-4','https://serviciodejardineria.com.ar/image/pTd1wZUgIqAuAnxBbo4CvfGCZx09Jg1UpHnHStcu.jpg','2023-09-28 19:34:34','2023-09-28 19:34:34'),
(104,1,16,'Servicio de Corte de Pasto y Limpieza en Ingeniero Maschwitz-5','servicio-de-corte-de-pasto-y-limpieza-en-ingeniero-maschwitz-5','https://serviciodejardineria.com.ar/image/jcAfTkF4qdilqcaVPJSHfMD8BMHoTapwUAfUwgoP.jpg','2023-09-28 19:36:30','2023-09-28 19:36:30'),
(105,1,16,'Servicio de Corte de Pasto y Limpieza en Ingeniero Maschwitz-6','servicio-de-corte-de-pasto-y-limpieza-en-ingeniero-maschwitz-6','https://serviciodejardineria.com.ar/image/SKQHyvxsvWFs2YNx55AugKJgwLUT131lwRPqziTj.jpg','2023-09-28 19:38:34','2023-09-28 19:38:34'),
(106,1,17,'Servicio de Poda de Altura en CABA','servicio-de-poda-de-altura-en-caba','https://serviciodejardineria.com.ar/image/v0BbXadQJaBduSl42HFbLwcqT6P8LZoYZpgL9m0j.jpg','2023-10-08 05:31:00','2023-10-08 05:31:00'),
(107,1,17,'Servicio de Poda de Altura en CABA-2','servicio-de-poda-de-altura-en-caba-2','https://serviciodejardineria.com.ar/image/oa9HwWrnXE1e0dCUNAAALFVSqgZueR24gUE5NrK0.jpg','2023-10-08 05:33:43','2023-10-08 05:33:43'),
(108,1,17,'Servicio de Poda de Altura en CABA-3','servicio-de-poda-de-altura-en-caba-3','https://serviciodejardineria.com.ar/image/ZJsovGQgUvE7pPzy45xRH78VQzLLDt2V1FFxPnCe.jpg','2023-10-08 05:34:37','2023-10-08 05:34:37'),
(109,1,17,'Servicio de Poda de Altura en CABA-4','servicio-de-poda-de-altura-en-caba-4','https://serviciodejardineria.com.ar/image/RRGWycIS527d9YntzK0YpGKAPMEUqjeJ04otXY3g.jpg','2023-10-08 05:36:17','2023-10-08 05:36:17'),
(110,1,17,'Servicio de Poda de Altura en CABA-5','servicio-de-poda-de-altura-en-caba-5','https://serviciodejardineria.com.ar/image/Hu1yVTE97VkU0pc8xIYnsuno6fryqkpeieEq5KHe.jpg','2023-10-08 05:37:40','2023-10-08 05:37:40'),
(111,1,17,'Servicio de Poda de Altura en CABA-6','servicio-de-poda-de-altura-en-caba-6','https://serviciodejardineria.com.ar/image/qzyjzGTLwPbEBTOPZocYLZJzemg977wAJjgVfPue.jpg','2023-10-08 05:38:38','2023-10-08 05:38:38'),
(112,1,17,'Servicio de Poda de Altura en CABA-7','servicio-de-poda-de-altura-en-caba-7','https://serviciodejardineria.com.ar/image/baZiJ1vSJVJ180iZC7jtAMpetcGKyfLyLTWfSd7r.jpg','2023-10-08 05:39:36','2023-10-08 05:39:36'),
(113,1,18,'Servicio de Desmalezado de Terreno en Matadero CABA','servicio-de-desmalezado-de-terreno-en-matadero-caba','https://serviciodejardineria.com.ar/image/DiOGUEC5QYDYzFTDbaqIC41T1uIn3jfnGaUMO84o.jpg','2023-10-15 19:41:04','2023-10-15 19:41:04'),
(114,1,18,'Servicio de Desmalezado de Terreno en Matadero CABA2','servicio-de-desmalezado-de-terreno-en-matadero-caba2','https://serviciodejardineria.com.ar/image/9AmSP80dGTxBpuk1eld1QDu5lJUvLUnGJKCOZlgn.jpg','2023-10-15 19:43:24','2023-10-15 19:43:24'),
(115,1,18,'Servicio de Desmalezado de Terreno en Matadero CABA3','servicio-de-desmalezado-de-terreno-en-matadero-caba3','https://serviciodejardineria.com.ar/image/zodeax9JX3dX86BMWO5lbktJ0EDCN0VEJTfWcjXB.jpg','2023-10-15 19:55:55','2023-10-15 19:55:55'),
(116,1,18,'Servicio de Desmalezado de Terreno en Matadero CABA4','servicio-de-desmalezado-de-terreno-en-matadero-caba4','https://serviciodejardineria.com.ar/image/ZQ8H57X4a1LlKqmKgzlG2wUh0XaPT7uXHLJW9khx.jpg','2023-10-15 19:56:07','2023-10-15 19:56:07'),
(117,1,19,'Servicio de Corte de Pasto en Villa Luzuriaga','servicio-de-corte-de-pasto-en-villa-luzuriaga','https://serviciodejardineria.com.ar/image/eiEH1vaNNgXIRdf3n3sQmGpKJio12JlKKnVRZWFx.jpg','2024-01-28 19:50:26','2024-01-28 19:50:26'),
(118,1,19,'Servicio de Corte de Pasto en Villa Luzuriaga1','servicio-de-corte-de-pasto-en-villa-luzuriaga1','https://serviciodejardineria.com.ar/image/ExuKOdQngJZzJmAqI6sYFtvH6AC8Q0MA27yurvqX.jpg','2024-01-28 19:50:55','2024-01-28 19:50:55'),
(119,1,19,'Servicio de Corte de Pasto en Villa Luzuriaga2','servicio-de-corte-de-pasto-en-villa-luzuriaga2','https://serviciodejardineria.com.ar/image/LTWomrFlVgperZJenmMLP9UabVhpoPYwdXMBSGFL.jpg','2024-01-28 19:51:10','2024-01-28 19:51:10'),
(121,1,19,'Servicio de Corte de Pasto en Villa Luzuriaga3','servicio-de-corte-de-pasto-en-villa-luzuriaga3','https://serviciodejardineria.com.ar/image/7m0iFZ7qxp08vUHyeiDTQQFFxcgpNKidq2GWh2bq.jpg','2024-01-28 19:51:52','2024-01-28 19:51:52'),
(122,1,19,'Servicio de Corte de Pasto en Villa Luzuriaga4','servicio-de-corte-de-pasto-en-villa-luzuriaga4','https://serviciodejardineria.com.ar/image/gmG1rOCWFqGdKD8TzLS509QxwjG5CRDwBCmgKhEv.jpg','2024-01-28 19:52:14','2024-01-28 19:52:14'),
(123,1,20,'Servicio de Mantenimiento de Jardines - San Martín','servicio-de-mantenimiento-de-jardines-san-martin','https://serviciodejardineria.com.ar/image/kFDLrt0pJQ9YxdyswcEYNQVzpDwXXsJL0DIETM0Q.jpg','2024-01-30 14:10:54','2024-01-30 14:10:54'),
(124,1,20,'Servicio de Mantenimiento de Jardines - San Martín1','servicio-de-mantenimiento-de-jardines-san-martin1','https://serviciodejardineria.com.ar/image/EqDu4GALnW9w0MHgx7clFpBao4kdY94qMRqGkddp.jpg','2024-01-30 14:11:27','2024-01-30 14:11:27'),
(125,1,20,'Servicio de Mantenimiento de Jardines - San Martín2','servicio-de-mantenimiento-de-jardines-san-martin2','https://serviciodejardineria.com.ar/image/DSDpAoBr96gaHWwrIwJkBggxOT0ugJjWoXlU403m.jpg','2024-01-30 14:11:46','2024-01-30 14:11:46'),
(126,1,20,'Servicio de Mantenimiento de Jardines - San Martín3','servicio-de-mantenimiento-de-jardines-san-martin3','https://serviciodejardineria.com.ar/image/jUHpCBZnCa0wvwYG3NbKxrMrHxw4wsrXAnUiMvUD.jpg','2024-01-30 14:12:06','2024-01-30 14:12:06'),
(127,1,20,'Servicio de Mantenimiento de Jardines - San Martín4','servicio-de-mantenimiento-de-jardines-san-martin4','https://serviciodejardineria.com.ar/image/UXBvHgwV9rToWblFWTxaEe4I0KIbQdguTkdhALIm.jpg','2024-01-30 14:12:24','2024-01-30 14:12:24'),
(128,1,20,'Servicio de Mantenimiento de Jardines - San Martín5','servicio-de-mantenimiento-de-jardines-san-martin5','https://serviciodejardineria.com.ar/image/cNwNCn2D9FcD9gPu1rwNjG9KhxhwcFIXg85jw9EI.jpg','2024-01-30 14:12:45','2024-01-30 14:12:45'),
(129,1,20,'Servicio de Mantenimiento de Jardines - San Martín6','servicio-de-mantenimiento-de-jardines-san-martin6','https://serviciodejardineria.com.ar/image/u8mE15MZdB3ITmr0TkwcAdyU4dkH8HI7EjmUFnCt.jpg','2024-01-30 14:13:06','2024-01-30 14:13:06'),
(130,1,20,'Servicio de Mantenimiento de Jardines - San Martín7','servicio-de-mantenimiento-de-jardines-san-martin7','https://serviciodejardineria.com.ar/image/PjqaYtc1qa2cl8tyNIL54W5iGxpdVEnqTTr19fvb.jpg','2024-01-30 14:13:23','2024-01-30 14:13:23'),
(131,1,20,'Servicio de Mantenimiento de Jardines - San Martín8','servicio-de-mantenimiento-de-jardines-san-martin8','https://serviciodejardineria.com.ar/image/36b13r8blMemCGkZ1HSH7pkiETRB2pFA4zZcWyM6.jpg','2024-01-30 14:13:42','2024-01-30 14:13:42'),
(132,1,20,'Servicio de Mantenimiento de Jardines - San Martín6','servicio-de-mantenimiento-de-jardines-san-martin9','https://serviciodejardineria.com.ar/image/Rs4B3ZvdTkah4H70w42BsPcBk3JzgeIabVilPt11.jpg','2024-01-30 14:14:12','2024-01-30 14:14:12'),
(143,1,21,'Servicio de Corte y Mantenimiento de Césped en Villa Mitre Buenos Aires Capital','servicio-de-corte-y-mantenimiento-de-cesped-en-villa-mitre-buenos-aires-capital','https://serviciodejardineria.com.ar/image/zvJfKaL1qyY9ziCFh2pKl3OuNe4aD0bv7DiQpENx.jpg','2024-06-10 00:48:27','2024-06-10 00:48:27'),
(144,1,21,'Servicio de Corte y Mantenimiento de Césped en Villa Mitre Buenos Aires Capital1','servicio-de-corte-y-mantenimiento-de-cesped-en-villa-mitre-buenos-aires-capital1','https://serviciodejardineria.com.ar/image/uZS8izfTScgVcA7MBj1P7Ac2E5GQ15vDpvhrh8xq.jpg','2024-06-10 00:51:50','2024-06-10 00:51:50'),
(145,1,22,'Servicio de Mantenimiento de Areas Verdes Para Empresas','servicio-de-mantenimiento-de-areas-verdes-para-empresas','https://serviciodejardineria.com.ar/image/L4fxMdn3ARkMLTvWnPJYMAy02ahEWd3RHNcgfPF2.jpg','2024-06-10 01:25:19','2024-06-10 01:25:19'),
(146,1,22,'Servicio de Mantenimiento de Areas Verdes Para Empresas-2','servicio-de-mantenimiento-de-areas-verdes-para-empresas-2','https://serviciodejardineria.com.ar/image/498GHCG6CqrzlzS2ljWJkC3bCNRbXDZvmqgFZyfn.jpg','2024-06-10 01:31:25','2024-06-10 01:31:25'),
(148,1,22,'Servicio de Mantenimiento de Areas Verdes Para Empresas-3','servicio-de-mantenimiento-de-areas-verdes-para-empresas-3','https://serviciodejardineria.com.ar/image/IxHy2RtbZVfPB3ibnN6ahDIrmCLzi7BkPmoiEMZv.jpg','2024-06-10 01:36:59','2024-06-10 01:36:59'),
(149,1,22,'Servicio de Mantenimiento de Areas Verdes Para Empresas-4','servicio-de-mantenimiento-de-areas-verdes-para-empresas-4','https://serviciodejardineria.com.ar/image/CGZKtQ8isuT7XtbSzAfBsWDe0FPBJiToH5JdVzd8.jpg','2024-06-10 01:40:21','2024-06-10 01:40:21'),
(150,1,22,'Servicio de Mantenimiento de Areas Verdes Para Empresas-5','servicio-de-mantenimiento-de-areas-verdes-para-empresas-5','https://serviciodejardineria.com.ar/image/XEjswa21tqW0RxUvcFMHnlAhADYbwPTjjD4wfrXy.jpg','2024-06-10 01:42:50','2024-06-10 01:42:50'),
(151,1,22,'Servicio de Mantenimiento de Areas Verdes Para Empresas-6','servicio-de-mantenimiento-de-areas-verdes-para-empresas-6','https://serviciodejardineria.com.ar/image/MRrSK1GoBoe0zXCGvGjIMJ88ItZWg4C0GwcByTww.jpg','2024-06-10 01:45:46','2024-06-10 01:45:46'),
(152,1,22,'Servicio de Mantenimiento de Areas Verdes Para Empresas-0','servicio-de-mantenimiento-de-areas-verdes-para-empresas-0','https://serviciodejardineria.com.ar/image/RUhG7F1zTR6RQMo5HFxelbOLrSiHpktuHj7NCOvo.jpg','2024-06-10 01:53:59','2024-06-10 01:53:59'),
(153,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar','https://serviciodejardineria.com.ar/image/n180Vn3jbUtxeKc1HTbYbWvmqUjG6Kh93LrVFnoe.jpg','2024-06-10 02:36:26','2024-06-10 02:36:26'),
(154,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-1','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-1','https://serviciodejardineria.com.ar/image/lSWyKbY9SDEToYJw4NiDgBYNj5ueT9zwR1CdWknx.jpg','2024-06-10 02:36:57','2024-06-10 02:36:57'),
(155,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-2','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-2','https://serviciodejardineria.com.ar/image/fZFTqeh4yL0Z8ygi1oMMChzlEFdFtqYiEa0GHqTX.jpg','2024-06-10 02:37:17','2024-06-10 02:37:17'),
(156,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-3','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-3','https://serviciodejardineria.com.ar/image/Xm0mEqobpTLyRMwX4bOkSV0C61jFqdNxeGj9SXvR.jpg','2024-06-10 02:37:35','2024-06-10 02:37:35'),
(157,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-4','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-4','https://serviciodejardineria.com.ar/image/MHoH0Ci2EzIZYIjYu2YfSj0eOApOg8TlfSPy2hLC.jpg','2024-06-10 02:38:30','2024-06-10 02:38:30'),
(158,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-5','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-5','https://serviciodejardineria.com.ar/image/tdO3Tc6dNqQBTWibX1aABdN8JApFBXMCV9isut4r.jpg','2024-06-10 02:38:48','2024-06-10 02:38:48'),
(159,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-6','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-6','https://serviciodejardineria.com.ar/image/FfG7vsD9HTHCs5GugRtKms3Cl4ssSd6G9SloNsb7.jpg','2024-06-10 02:52:32','2024-06-10 02:52:32'),
(160,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-7','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-7','https://serviciodejardineria.com.ar/image/FXOFh1jpC50iXuq9ndT3qnTPbXTpIv8raYkqSd2W.jpg','2024-06-10 02:52:59','2024-06-10 02:52:59'),
(161,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-8','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-8','https://serviciodejardineria.com.ar/image/yPdql8fNEbizmgbfiuG8ERTvjELH6FqGrUjHt020.jpg','2024-06-10 02:53:31','2024-06-10 02:53:31'),
(162,1,23,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar-9','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar-9','https://serviciodejardineria.com.ar/image/IevsKY7w1dC1U767btKA5UaBiIF57uz0djSPGt0F.jpg','2024-06-10 02:53:52','2024-06-10 02:53:52'),
(163,1,24,'Servicio de Mantenimiento de Áreas Verdes para Empresas en Buenos Aires','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-buenos-aires','https://serviciodejardineria.com.ar/image/bAstN0rvkcfBZgt894NK9qmyjZuW3SQYXoMieK71.jpg','2024-08-31 19:43:16','2024-08-31 19:43:16'),
(164,1,25,'Servicio de Desmalezado y Limpieza de Jardin en Maschwitz','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz','https://serviciodejardineria.com.ar/image/EBdgKY7nr9rRNLn3Ui0J4QJcFI2ajkkygoSDUCak.jpg','2024-09-30 01:50:48','2024-09-30 01:50:48'),
(165,1,25,'Servicio de Desmalezado y Limpieza de Jardin en Maschwitz1','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz1','https://serviciodejardineria.com.ar/image/tj2iqng8GVWQBsFn94oKTRj6UzUug8bK2j22a3Ay.jpg','2024-09-30 01:53:38','2024-09-30 01:53:38'),
(166,1,25,'Servicio de Desmalezado y Limpieza de Jardin en Maschwitz-2','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz-2','https://serviciodejardineria.com.ar/image/tMQRx8sMm5scqEn2g7PnUCa5ZcDRSjayR55qfoly.jpg','2024-09-30 01:53:55','2024-09-30 01:53:55'),
(167,1,25,'Servicio de Desmalezado y Limpieza de Jardin en Maschwitz-3','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz-3','https://serviciodejardineria.com.ar/image/H7PvIDByHfbzp3LNs3asgjSZuxxq9Vl86Rl8WHQy.jpg','2024-09-30 01:54:16','2024-09-30 01:54:16'),
(168,1,25,'Servicio de Desmalezado y Limpieza de Jardin en Maschwitz-4','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz-4','https://serviciodejardineria.com.ar/image/mLwjuAA9GIUHp8fyhiwaD7R4jbqEGCCU3pGI3KQn.jpg','2024-09-30 01:54:36','2024-09-30 01:54:36'),
(169,1,25,'Servicio de Desmalezado y Limpieza de Jardin en Maschwitz-5','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz-5','https://serviciodejardineria.com.ar/image/ZUUM36ILNZyAiIUNUEUcGJiv6dUPdTxij0qffHSC.jpg','2024-09-30 01:54:56','2024-09-30 01:54:56'),
(170,1,25,'Servicio de Desmalezado y Limpieza de Jardin en Maschwitz-6','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz-6','https://serviciodejardineria.com.ar/image/MvC9GVyNX9tdg7B9fNIpastAIUl2A6uAd8TPGJAR.jpg','2024-09-30 01:55:09','2024-09-30 01:55:09'),
(171,1,25,'Servicio de Desmalezado y Limpieza de Jardin en Maschwitz-8','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz-8','https://serviciodejardineria.com.ar/image/Q1culq7JK6rkpIdPn9KHKfOA3qTyXdCmBFYwDTT6.jpg','2024-09-30 01:55:20','2024-09-30 01:55:20'),
(182,1,27,'Corte-de-Pasto-con-Tractor-Cortacesped-para-Empresas11','corte-de-pasto-con-tractor-cortacesped-para-empresas11','https://serviciodejardineria.com.ar/image/FnMxW0dDgdet0ABNuW2DrnikbYtIe02X8mZL5XB3.jpg','2025-06-30 20:10:22','2025-06-30 20:10:22'),
(183,1,27,'Corte-de-Pasto-con-Tractor-Cortacesped-para-Empresas22','corte-de-pasto-con-tractor-cortacesped-para-empresas22','https://serviciodejardineria.com.ar/image/BR8VPFFgLkWjG8HHG1XhhARo8nAWXcuOsjhuBDdi.jpg','2025-06-30 20:11:01','2025-06-30 20:11:01'),
(184,1,29,'Servicio Poda de Altura para Empresas','servicio-poda-de-altura-para-empresas','https://serviciodejardineria.com.ar/image/VagvzecDmxIXuibAxchhshEWdjFs3pVgVBXllgFa.jpg','2025-06-30 20:16:54','2025-06-30 20:16:54'),
(185,1,28,'Servicio de Poda de Altura en Caballito','servicio-de-poda-de-altura-en-caballito','https://serviciodejardineria.com.ar/image/a1KP9gG81Ohl7euLsBaRhP5An9PZCwcRrX3dUnE9.jpg','2025-06-30 20:20:16','2025-06-30 20:20:16'),
(186,1,28,'Servicio de Poda de Altura en Caballito2','servicio-de-poda-de-altura-en-caballito2','https://serviciodejardineria.com.ar/image/C53M1n8KnnewUwyybXLKpVFZdllGD0D60miscoTI.jpg','2025-06-30 20:21:21','2025-06-30 20:21:21'),
(187,1,26,'Poda de Altura en San Martín','poda-de-altura-en-san-martin','https://serviciodejardineria.com.ar/image/SSXFzSdfdGg5WnNPtwY0Q84eLfMJ1XExWtvxiKa5.jpg','2025-06-30 20:22:59','2025-06-30 20:22:59'),
(188,1,26,'Poda de Altura en San Martín2','poda-de-altura-en-san-martin2','https://serviciodejardineria.com.ar/image/2fEBKHhG6QdfiSHdnhfRkLDO2bBy2PRnguYZMi14.jpg','2025-06-30 20:23:15','2025-06-30 20:23:15'),
(189,1,26,'Poda de Altura en San Martín3','poda-de-altura-en-san-martin3','https://serviciodejardineria.com.ar/image/lWioS0RBYlA9qNBwpYmkRhtVe0uqZJQUvI0MwEuv.jpg','2025-06-30 20:23:44','2025-06-30 20:23:44'),
(190,1,30,'Servicio de Poda de Altura en San Martín','servicio-de-poda-de-altura-en-san-martin','https://serviciodejardineria.com.ar/image/MK7M0OrCgf9GZueentCJ3XqPcvyh5IFlPmtB49s3.jpg','2025-07-07 12:57:05','2025-07-07 12:57:06'),
(191,1,30,'Servicio de Poda de Altura en San Martín 2','servicio-de-poda-de-altura-en-san-martin-2','https://serviciodejardineria.com.ar/image/FgyolVLkr9oq3oCgDnVmXMy7H2q1PyMz7gEQI72d.jpg','2025-07-07 12:57:19','2025-07-07 12:57:19'),
(192,1,31,'Servicio de Corte de Pasto en Canchas de Rugby','servicio-de-corte-de-pasto-en-canchas-de-rugby','https://serviciodejardineria.com.ar/image/8EfBTi9wDdBRkMU8Uc2xdhK6qcExWhbeE9fNCbvN.jpg','2025-10-05 20:57:14','2025-10-05 20:57:14'),
(193,1,31,'Servicio de Corte de Pasto en Canchas de Rugby-2','servicio-de-corte-de-pasto-en-canchas-de-rugby-2','https://serviciodejardineria.com.ar/image/VMh0GlJtJ4nrYcPGM8KXfXpAMlEYpd5bgR3I8TK1.jpg','2025-10-05 20:57:49','2025-10-05 20:57:49'),
(194,1,32,'Servicio de Desmalezado y Limpieza de Terrenos en Villa Urquiza','servicio-de-desmalezado-y-limpieza-de-terrenos-en-villa-urquiza','https://serviciodejardineria.com.ar/image/N1v2jkAIijeLe5HXMVJivJsAoz2YtioSfkNnxISY.jpg','2026-01-11 20:55:27','2026-01-11 20:55:27'),
(195,1,32,'Servicio de Desmalezado y Limpieza de Terrenos en Villa Urquiza – CABA','servicio-de-desmalezado-y-limpieza-de-terrenos-en-villa-urquiza-caba','https://serviciodejardineria.com.ar/image/rlZWpXCBUECA5QHGm3rvVrkJOcEnLtcrTvr8JALj.jpg','2026-01-11 20:55:51','2026-01-11 20:55:51'),
(196,1,32,'Servicio de Desmalezado y Limpieza de Terrenos en Villa Urquiza – CABA – BA','servicio-de-desmalezado-y-limpieza-de-terrenos-en-villa-urquiza-caba-ba','https://serviciodejardineria.com.ar/image/LmhNTi2wa7MtWSfIaBHJPz8ui8X6ZM3TS5wB5JaK.jpg','2026-01-11 20:57:10','2026-01-11 20:57:10'),
(197,1,32,'Servicio de Desmalezado y Limpieza de Terrenos en Villa Urquiza – CABA – Buenos Aires','servicio-de-desmalezado-y-limpieza-de-terrenos-en-villa-urquiza-caba-buenos-aires','https://serviciodejardineria.com.ar/image/mRwrJJEpyNyCgz8RQRXkkwrOi6LjLUKnT4HiHlzi.jpg','2026-01-11 20:57:29','2026-01-11 20:57:29'),
(198,1,32,'Servicio de Desmalezado y Limpieza de Terrenos en Villa Urquiza – CABA – Buenos Aires: Caso Ivana','servicio-de-desmalezado-y-limpieza-de-terrenos-en-villa-urquiza-caba-buenos-aires-caso-ivana','https://serviciodejardineria.com.ar/image/mquCXdrPpKbLooCFRKgSRhafPO0SauJSXJZjvp6Y.jpg','2026-01-11 20:57:56','2026-01-11 20:57:56'),
(199,1,32,'Desmalezado y Limpieza de Terrenos en Villa Urquiza – CABA – Buenos Aires: Caso Ivana','desmalezado-y-limpieza-de-terrenos-en-villa-urquiza-caba-buenos-aires-caso-ivana','https://serviciodejardineria.com.ar/image/nVEKVyI91Q8B6BIUjBk24fEs8RFyEl5S0zxQxOvN.jpg','2026-01-11 20:58:17','2026-01-11 20:58:17'),
(200,1,32,'Limpieza de Terrenos en Villa Urquiza – CABA – Buenos Aires: Caso Ivana','limpieza-de-terrenos-en-villa-urquiza-caba-buenos-aires-caso-ivana','https://serviciodejardineria.com.ar/image/jIypCPPVZI8EK6H17aQtTU86EF4kcvcC0fjD5rsc.jpg','2026-01-11 20:58:34','2026-01-11 20:58:34'),
(201,1,32,'Servicio de Limpieza de Terrenos en Villa Urquiza – CABA – Buenos Aires: Caso Ivana','servicio-de-limpieza-de-terrenos-en-villa-urquiza-caba-buenos-aires-caso-ivana','https://serviciodejardineria.com.ar/image/e7L0Zduqu3HvekHqiy5weFcnspPz860vcsCEoC7E.jpg','2026-01-11 20:58:54','2026-01-11 20:58:54'),
(202,1,32,'Limpieza de Terreno en Villa Urquiza – CABA – Buenos Aires: Caso Ivana','limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-ivana','https://serviciodejardineria.com.ar/image/K8AsP1qw2v1VpQEg5U8CC5ki0QrjXI3OqVgBdX61.jpg','2026-01-11 20:59:28','2026-01-11 20:59:28'),
(203,1,32,'Desmalezado en Villa Urquiza','desmalezado-en-villa-urquiza','https://serviciodejardineria.com.ar/image/ncsTKjUe5fKdeulTf825iGkuQsoJU86SmT7LnEXQ.jpg','2026-01-11 21:00:10','2026-01-11 21:00:10'),
(204,1,32,'Limpieza de Terrenos en Villa Urquiza','limpieza-de-terrenos-en-villa-urquiza','https://serviciodejardineria.com.ar/image/uttgy2gigVK2oQP9VETQOpgrNFnaflLaNy5y8iLr.jpg','2026-01-11 21:00:30','2026-01-11 21:00:30'),
(205,1,32,'Limpieza de Terrenos en Villa Urquiza – CABA','limpieza-de-terrenos-en-villa-urquiza-caba','https://serviciodejardineria.com.ar/image/Y4mGUIYrVgDenlrQQFY94klzwnlBYRSFr3bptyTh.jpg','2026-01-11 21:00:53','2026-01-11 21:00:53'),
(206,1,32,'Limpieza de Terrenos en Villa Urquiza – CABA – Buenos Aires','limpieza-de-terrenos-en-villa-urquiza-caba-buenos-aires','https://serviciodejardineria.com.ar/image/B3mcvIPMyIlhosHWME3P4jxMqfmx0sn8OOGhV1Vm.jpg','2026-01-11 21:01:13','2026-01-11 21:01:13'),
(207,1,32,'Limpieza de Terrenos en Villa Urquiza – CABA – BA','limpieza-de-terrenos-en-villa-urquiza-caba-ba','https://serviciodejardineria.com.ar/image/0dQWkeXGujMS94p4bx7gJa9T8UwYX0lhi5z7d5DM.jpg','2026-01-11 21:01:34','2026-01-11 21:01:34'),
(208,1,32,'Desmalezado y Limpieza de Terreno en Villa Urquiza – CABA – Buenos Aires: Caso Ivana','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-ivana','https://serviciodejardineria.com.ar/image/sh94nJZuY1QpqaIBgZcyV23uJPZiE3Zt7brQr4Uu.jpg','2026-01-11 21:02:35','2026-01-11 21:02:35'),
(209,1,33,'poda en altura','poda-en-altura','https://serviciodejardineria.com.ar/image/cdRBAydAZMorIRmzN8PYPFmTns0dKOWZL5IKmQnX.jpg','2026-01-11 21:57:54','2026-01-11 21:57:54'),
(210,1,33,'poda de altura','poda-de-altura','https://serviciodejardineria.com.ar/image/xNdJEJuBTW5TzN5rM01XERsg1RWM9ZqzQvRewjcL.jpg','2026-01-11 21:58:16','2026-01-11 21:58:16'),
(211,1,33,'poda en altura en Saavedra','poda-en-altura-en-saavedra','https://serviciodejardineria.com.ar/image/JDgVknd2uimjAQKaMacQaYDV6jtCQihIu9G0G3r2.jpg','2026-01-11 21:58:37','2026-01-11 21:58:37'),
(212,1,33,'poda de altura en Saavedra','poda-de-altura-en-saavedra','https://serviciodejardineria.com.ar/image/lm1qN6kMvKCsy8GdzvJeKDJxKhii3Jt0I6mw9Jyu.jpg','2026-01-11 21:59:02','2026-01-11 21:59:02'),
(213,1,33,'poda en altura en Saavedra Buenos Aires','poda-en-altura-en-saavedra-buenos-aires','https://serviciodejardineria.com.ar/image/oEHir6WTcDuixsgR2VO6FJ9Ujao2Jcs3jFsmKx9t.jpg','2026-01-11 21:59:36','2026-01-11 21:59:36'),
(214,1,34,'limpieza 1','limpieza-1','https://serviciodejardineria.com.ar/image/muVceP2Dn4ZKmCEgVJz30X10NBEGwW187yfasULU.jpg','2026-01-13 23:10:26','2026-01-13 23:10:26'),
(215,1,34,'limpieza 2','limpieza-2','https://serviciodejardineria.com.ar/image/tPc3ZdCfsGwzeprZL818sZwLTVTaRDUF1bAJmBKC.jpg','2026-01-13 23:10:49','2026-01-13 23:10:49'),
(216,1,34,'limpieza de terrenos','limpieza-de-terrenos','https://serviciodejardineria.com.ar/image/G84KdpzUnqZqwLdfieFzfttbKhxZRGxMXbKOrNSq.jpg','2026-01-13 23:11:32','2026-01-13 23:11:32'),
(217,1,34,'limpieza 3','limpieza-3','https://serviciodejardineria.com.ar/image/HwAReAwRXLGpJXnB6a3AVyeI9e206IdFdjvgxj0T.jpg','2026-01-13 23:12:44','2026-01-13 23:12:44'),
(218,1,35,'Expertos en Poda de Enredaderas en Buenos Aires','expertos-en-poda-de-enredaderas-en-buenos-aires','https://serviciodejardineria.com.ar/image/P3Dpb6g16ku8vcW6whtYqYpafjA9nxmo7Hz8VZIm.jpg','2026-01-31 18:26:31','2026-01-31 18:26:31'),
(219,1,35,'Expertos en Poda de Enredaderas en Buenos Aires 2','expertos-en-poda-de-enredaderas-en-buenos-aires-2','https://serviciodejardineria.com.ar/image/vNSuGlQLxXBLqRcMwCeXbhSvKThMCM09FAZ1zIiI.jpg','2026-01-31 18:28:13','2026-01-31 18:28:13'),
(220,1,35,'Expertos en Poda de Enredaderas en Buenos Aires 3','expertos-en-poda-de-enredaderas-en-buenos-aires-3','https://serviciodejardineria.com.ar/image/6Se8uGz9UH4QO4aWsrnb9Oxe7EqtUL6BqSiSJ355.jpg','2026-01-31 18:28:34','2026-01-31 18:28:34'),
(221,1,36,'Desmalezado y Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-cesar','https://serviciodejardineria.com.ar/image/0RgARK45x9PJ0JgwDgB3blmrGZGdi8eNwayv6hFn.jpg','2026-02-02 02:31:43','2026-02-02 02:31:43'),
(222,1,36,'Desmalezado y Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César 2','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-cesar-2','https://serviciodejardineria.com.ar/image/Q346SsUBoM5nMTRAIP5Pie376RnnZqvr0V5H7h40.jpg','2026-02-02 02:32:00','2026-02-02 02:32:00'),
(223,1,36,'Desmalezado y Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César 3','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-cesar-3','https://serviciodejardineria.com.ar/image/Inz36GzbLAW70xPlwbNN0HqYKUeYyTtriwV06shj.jpg','2026-02-02 02:32:16','2026-02-02 02:32:16'),
(224,1,36,'Desmalezado y Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César 4','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-cesar-4','https://serviciodejardineria.com.ar/image/2IQNBcaZZHjdOaV8UrerWAZ5V2TJ8WVxgpTvkJc6.jpg','2026-02-02 02:32:36','2026-02-02 02:32:36'),
(225,1,36,'Desmalezado y Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César 5','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-cesar-5','https://serviciodejardineria.com.ar/image/RVwlIEkLu5rjTSqPwEQrJ9ETafYCXpYHLcKX7FPV.jpg','2026-02-02 02:32:53','2026-02-02 02:32:53'),
(226,1,36,'Desmalezado y Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César 6','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-cesar-6','https://serviciodejardineria.com.ar/image/UQot71rloJVpdAfnqHidivJjDk29U3QeYBcBXzgw.jpg','2026-02-02 02:33:13','2026-02-02 02:33:13'),
(227,1,36,'Desmalezado y Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César 7','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-cesar-7','https://serviciodejardineria.com.ar/image/ocdUweAenovxf40oVaFJLMlMfnfxyWOBUS32XZko.jpg','2026-02-02 02:33:33','2026-02-02 02:33:33'),
(228,1,37,'Poda de Seguridad en Altura Saavedra: Eliminamos el Riesgo de un Pino de 12 Metros y un Laurel Peligroso','poda-de-seguridad-en-altura-saavedra-eliminamos-el-riesgo-de-un-pino-de-12-metros-y-un-laurel-peligroso','https://serviciodejardineria.com.ar/image/jQOr9qBVPEM8Zl7e6MTXbqy3DIPOGlXhJdjNzrDo.jpg','2026-02-04 12:33:08','2026-02-04 12:33:08'),
(229,1,37,'Poda de Seguridad en Altura Saavedra: Eliminamos el Riesgo de un Pino de 12 Metros y un Laurel Peligroso 2','poda-de-seguridad-en-altura-saavedra-eliminamos-el-riesgo-de-un-pino-de-12-metros-y-un-laurel-peligroso-2','https://serviciodejardineria.com.ar/image/gUtQv17tpHmLve9uylSCDktOrb92fJTDQ5cVPAWK.jpg','2026-02-04 12:33:44','2026-02-04 12:33:44'),
(230,1,37,'Poda de Seguridad en Altura Saavedra: Eliminamos el Riesgo de un Pino de 12 Metros y un Laurel Peligroso 3','poda-de-seguridad-en-altura-saavedra-eliminamos-el-riesgo-de-un-pino-de-12-metros-y-un-laurel-peligroso-3','https://serviciodejardineria.com.ar/image/9HOwiZWOJwU7b7tDoj0ZeAqyCnVQbgRi2AUikKBM.jpg','2026-02-04 12:36:45','2026-02-04 12:36:45'),
(231,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos','https://serviciodejardineria.com.ar/image/olgRp2ovkYnnQIJE5bcTs6VQEmODEtuCWFM7A2XF.jpg','2026-03-05 14:39:53','2026-03-05 14:39:53'),
(232,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 2','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-2','https://serviciodejardineria.com.ar/image/6diYUotRGN9BJ8G5kK4b2b6cecxQRyyunvaJo3UY.jpg','2026-03-05 14:41:37','2026-03-05 14:41:38'),
(233,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 3','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-3','https://serviciodejardineria.com.ar/image/7h9sbx62zHOprwCPKAE1nF0H5bbtu723b3psJ13E.jpg','2026-03-05 14:41:51','2026-03-05 14:41:51'),
(234,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 4','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-4','https://serviciodejardineria.com.ar/image/gT3lY4A9zmxR4iQjjlhkqoGSIsm3ODnZ2UsYClrp.jpg','2026-03-05 14:42:00','2026-03-05 14:42:00'),
(235,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 5','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-5','https://serviciodejardineria.com.ar/image/vN5DnihkYsknq0lJe8nmwSYMxdWAs7ggpm886Nkg.jpg','2026-03-05 14:42:11','2026-03-05 14:42:11'),
(236,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 6','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-6','https://serviciodejardineria.com.ar/image/WJNlhigt5EpoLs2H5FfCgCxj5GIYb5NNWoZyTRbN.jpg','2026-03-05 14:42:26','2026-03-05 14:42:26'),
(237,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 7','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-7','https://serviciodejardineria.com.ar/image/ILKL5X6rEe8A7x8y9BFQlQsw9J9My6fBKZZvbfKd.jpg','2026-03-05 14:42:37','2026-03-05 14:42:37'),
(238,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 8','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-8','https://serviciodejardineria.com.ar/image/insbMf9tC7MQOIGxmwekWj0aKVH8syWp8c9t5ouH.jpg','2026-03-05 14:42:48','2026-03-05 14:42:48'),
(239,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 9','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-9','https://serviciodejardineria.com.ar/image/kF3Ey4750JGSPsR3N3Vve8CJhyY2sgLQxlwYBSfB.jpg','2026-03-05 14:42:58','2026-03-05 14:42:58'),
(240,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 10','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-10','https://serviciodejardineria.com.ar/image/bhaGjXZ992s3xIunzdy0S5qRN7Zfem3QccW4QkHH.jpg','2026-03-05 14:43:10','2026-03-05 14:43:10'),
(241,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 11','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-11','https://serviciodejardineria.com.ar/image/4kiB4XMrictEJymz5yxBsL6Ih4ZKeK79tCxff53e.jpg','2026-03-05 14:43:21','2026-03-05 14:43:21'),
(242,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 12','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-12','https://serviciodejardineria.com.ar/image/gNtbCydnk0LhzhYnRkghWwhySs4u1IYMxmbSXGtf.jpg','2026-03-05 14:43:36','2026-03-05 14:43:36'),
(243,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 13','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-13','https://serviciodejardineria.com.ar/image/4FnNaWJYYwRgHWU7nDqxiuOAqbUgwfh3ipx8qfx2.jpg','2026-03-05 14:43:50','2026-03-05 14:43:50'),
(244,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 14','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-14','https://serviciodejardineria.com.ar/image/4vFsxHaQqQ9cNF6W6wOHKCPJJHxybg5BRYpqM6J6.jpg','2026-03-05 14:44:17','2026-03-05 14:44:17'),
(245,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 18','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-18','https://serviciodejardineria.com.ar/image/YBAPi07HQkPRVVSBO3tYBYQgxHjFWi0wWP2Ab01F.jpg','2026-03-05 14:44:36','2026-03-05 14:44:36'),
(246,1,38,'Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 15','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires-caso-juan-carlos-15','https://serviciodejardineria.com.ar/image/839tcBdjQjIqNbjuI1IC7UTAYllVY3Ee7Zdd9VK3.jpg','2026-03-05 14:44:49','2026-03-05 14:44:49'),
(247,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba','https://serviciodejardineria.com.ar/image/eZCQJtGtiSPXWmfsB6qeSIWxgj5LKgITryeioRWI.jpg','2026-03-26 13:13:00','2026-03-26 13:13:00'),
(248,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 2','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-2','https://serviciodejardineria.com.ar/image/r2fVXJxNcDZ2fwInh3nZppBGEBHBetmheQzAWNAZ.jpg','2026-03-26 13:51:20','2026-03-26 13:51:20'),
(249,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 3','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-3','https://serviciodejardineria.com.ar/image/DZjZlQlOWPLFSagVsgx83gX2j2VM1oewuccYyrus.jpg','2026-03-26 13:51:55','2026-03-26 13:51:55'),
(250,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 4','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-4','https://serviciodejardineria.com.ar/image/sdn3Q3hV228iWEHVQOiNqi9ZxWBA1zJ8oqpBdanz.jpg','2026-03-26 13:52:13','2026-03-26 13:52:13'),
(251,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 5','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-5','https://serviciodejardineria.com.ar/image/KjExT1vqkZt2WjAbdUF8tlCMXs8ahm0NjpG9TLQ7.jpg','2026-03-26 13:52:37','2026-03-26 13:52:37'),
(253,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 6','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-6','https://serviciodejardineria.com.ar/image/0V9SIXLY57oJBRecZLqpjuQVQuYQHczcAloNVAKx.jpg','2026-03-26 13:53:26','2026-03-26 13:53:26'),
(254,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 7','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-7','https://serviciodejardineria.com.ar/image/5gkQjUIxKbqHHY1qtmhBMNeFHVw4eHKcup7pK33H.jpg','2026-03-26 13:53:57','2026-03-26 13:53:57'),
(255,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 8','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-8','https://serviciodejardineria.com.ar/image/qOvFMN5oVab47dQ1QsDZkY3sCwSOM4BsAzosHgS7.jpg','2026-03-26 13:54:21','2026-03-26 13:54:21'),
(256,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 9','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-9','https://serviciodejardineria.com.ar/image/QX0t2VCMtZBNs0pNSkKs7NkSTiD5mZJmQjkaRGwv.jpg','2026-03-26 13:54:45','2026-03-26 13:54:45'),
(257,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 10','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-10','https://serviciodejardineria.com.ar/image/FMg5W8QuyTD3Fjruu2b3UbgLhZrw5VKC1Ckd73Hw.jpg','2026-03-26 13:55:05','2026-03-26 13:55:05'),
(258,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 11','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-11','https://serviciodejardineria.com.ar/image/uA6YRKZDcqACum1UX2KlsgCxQbNmHgxo6GHsFTQr.jpg','2026-03-26 13:55:23','2026-03-26 13:55:23'),
(259,1,39,'Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA 12','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba-12','https://serviciodejardineria.com.ar/image/dgksavfhT5SOvSlyFSCPFOh4Xp3pUSRqTlkSo0nq.jpg','2026-03-26 13:55:44','2026-03-26 13:55:44'),
(260,1,40,'Servicio de Poda de Altura en Palermo – Buenos Aires','servicio-de-poda-de-altura-en-palermo-buenos-aires','https://serviciodejardineria.com.ar/image/J5uYtsS4VFWxQmPloTerOEZLlqOiQ7crCluzV2CH.jpg','2026-05-25 20:23:29','2026-05-25 20:23:29'),
(261,1,40,'Servicio de Poda de Altura en Palermo – Buenos Aires 2','servicio-de-poda-de-altura-en-palermo-buenos-aires-2','https://serviciodejardineria.com.ar/image/xFWybxbPeuObeKCufGJ3NqA5T604zXQahv5MVPxj.jpg','2026-05-25 20:23:44','2026-05-25 20:23:44'),
(262,1,40,'Servicio de Poda de Altura en Palermo – Buenos Aires 3','servicio-de-poda-de-altura-en-palermo-buenos-aires-3','https://serviciodejardineria.com.ar/image/RbbuF5B7ohE8i7ni7yjHDHjolBgmg02bjbJExgQp.jpg','2026-05-25 20:23:58','2026-05-25 20:23:58'),
(263,1,40,'Servicio de Poda de Altura en Palermo – Buenos Aires 4','servicio-de-poda-de-altura-en-palermo-buenos-aires-4','https://serviciodejardineria.com.ar/image/O2EQcCgQU4KNzYkvfEjs1FUPsq5jpPL8OJgIHQtz.jpg','2026-05-25 20:24:14','2026-05-25 20:24:14'),
(264,1,41,'Poda de Altura y Nivelación de Terreno-','poda-de-altura-y-nivelacion-de-terreno','https://serviciodejardineria.com.ar/image/x3s13E2HvZ2UzsSRF6JAldcEihPMyeW2jY07F6fF.jpg','2026-07-07 14:43:26','2026-07-07 14:43:26'),
(265,1,41,'Poda de Altura y Nivelación de Terreno-2','poda-de-altura-y-nivelacion-de-terreno-2','https://serviciodejardineria.com.ar/image/MbyHGhYYu90OHa3BBR9r12JFTJGGPQSv2uOXwqOj.jpg','2026-07-07 14:44:48','2026-07-07 14:44:48'),
(266,1,41,'Poda de Altura y Nivelación de Terreno-3','poda-de-altura-y-nivelacion-de-terreno-3','https://serviciodejardineria.com.ar/image/Mh0uYlaGeBVcsAwC9KAVc2esIkaNDG3yOpI4NIJw.jpg','2026-07-07 14:45:35','2026-07-07 14:45:35'),
(267,1,41,'Poda de Altura y Nivelación de Terreno-4','poda-de-altura-y-nivelacion-de-terreno-4','https://serviciodejardineria.com.ar/image/dShgJI3Rq9fE7BnQALQ9o7t9fbYAfJcYmmC0f4IE.jpg','2026-07-07 14:46:24','2026-07-07 14:46:24'),
(268,1,41,'Poda de Altura y Nivelación de Terreno-5','poda-de-altura-y-nivelacion-de-terreno-5','https://serviciodejardineria.com.ar/image/rNHWE2Re21O936krdFS0BthEVrNw2x1bXFSws1Mv.jpg','2026-07-07 14:46:58','2026-07-07 14:46:58'),
(269,1,41,'Poda de Altura y Nivelación de Terreno-6','poda-de-altura-y-nivelacion-de-terreno-6','https://serviciodejardineria.com.ar/image/V4DglGt2KcJHKFkNeIxKZCchGopP2Clx0PKSrbjR.jpg','2026-07-07 14:47:12','2026-07-07 14:47:12'),
(270,1,41,'Poda de Altura y Nivelación de Terreno-7','poda-de-altura-y-nivelacion-de-terreno-7','https://serviciodejardineria.com.ar/image/MOsQMFZbBtcrO9w5BPmNcESYA0sUJ6MciCSWTjQJ.jpg','2026-07-07 14:47:48','2026-07-07 14:47:48'),
(271,1,42,'Servicio de Poda de Árboles en Buenos Aires','servicio-de-poda-de-arboles-en-buenos-aires','https://serviciodejardineria.com.ar/image/rf7zscZbPZDowJLzfnA1REYMACctuHResRDtHc7M.jpg','2026-07-08 19:59:05','2026-07-08 19:59:05'),
(272,1,42,'Servicio de Poda de Árboles en Buenos Aires-2','servicio-de-poda-de-arboles-en-buenos-aires-2','https://serviciodejardineria.com.ar/image/EnDWP4xtVbrcZdT0HNOcKQpx9GewtodG5tZM2yIA.jpg','2026-07-08 20:00:26','2026-07-08 20:00:26'),
(273,1,42,'Servicio de Poda de Árboles en Buenos Aires-3','servicio-de-poda-de-arboles-en-buenos-aires-3','https://serviciodejardineria.com.ar/image/qK2eVxtdPx1IxRZPcOETFHPiG3cqLSty3d5Vxtp6.jpg','2026-07-08 20:00:51','2026-07-08 20:00:51'),
(274,1,42,'Servicio de Poda de Árboles en Buenos Aires-4','servicio-de-poda-de-arboles-en-buenos-aires-4','https://serviciodejardineria.com.ar/image/F3EhS92YEHoHNSraV5SAFTBlLiOEVYLkO7U80GMH.jpg','2026-07-08 20:03:17','2026-07-08 20:03:17'),
(275,1,42,'Servicio de Poda de Árboles en Buenos Aires-5','servicio-de-poda-de-arboles-en-buenos-aires-5','https://serviciodejardineria.com.ar/image/AFFEeXYo9w70X3yBYpPKJ2ozPLw2UPnU5peadsuV.jpg','2026-07-08 20:04:04','2026-07-08 20:04:04');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(57,'2014_10_12_000000_create_users_table',1),
(58,'2014_10_12_100000_create_password_resets_table',1),
(59,'2019_08_19_000000_create_failed_jobs_table',1),
(60,'2019_12_14_000001_create_personal_access_tokens_table',1),
(61,'2022_10_13_174013_create_categories_table',1),
(62,'2022_10_13_174111_create_tags_table',1),
(63,'2022_10_13_174128_create_posts_table',1),
(64,'2022_10_13_193500_create_post_tag_table',1),
(65,'2022_10_16_163856_create_images_table',1),
(66,'2022_10_21_205935_create_clientes_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `post_tag`
--

DROP TABLE IF EXISTS `post_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_tag` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `tag_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_tag_post_id_foreign` (`post_id`),
  KEY `post_tag_tag_id_foreign` (`tag_id`),
  CONSTRAINT `post_tag_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `post_tag` WRITE;
/*!40000 ALTER TABLE `post_tag` DISABLE KEYS */;
INSERT INTO `post_tag` VALUES
(1,1,2,NULL,NULL),
(2,1,1,NULL,NULL),
(3,2,2,NULL,NULL),
(4,3,2,NULL,NULL),
(5,3,1,NULL,NULL),
(6,4,2,NULL,NULL),
(7,4,1,NULL,NULL),
(8,5,2,NULL,NULL),
(9,5,1,NULL,NULL),
(10,6,2,NULL,NULL),
(11,6,1,NULL,NULL),
(12,6,3,NULL,NULL),
(13,6,4,NULL,NULL),
(18,8,2,NULL,NULL),
(19,8,3,NULL,NULL),
(20,8,4,NULL,NULL),
(21,8,1,NULL,NULL),
(22,9,1,NULL,NULL),
(23,9,5,NULL,NULL),
(24,10,2,NULL,NULL),
(25,10,5,NULL,NULL),
(26,11,6,NULL,NULL),
(27,11,2,NULL,NULL),
(28,11,7,NULL,NULL),
(29,12,5,NULL,NULL),
(30,12,3,NULL,NULL),
(31,13,5,NULL,NULL),
(32,14,2,NULL,NULL),
(33,14,1,NULL,NULL),
(34,15,6,NULL,NULL),
(35,15,2,NULL,NULL),
(36,15,1,NULL,NULL),
(37,15,5,NULL,NULL),
(38,15,3,NULL,NULL),
(39,15,4,NULL,NULL),
(40,16,6,NULL,NULL),
(41,16,2,NULL,NULL),
(42,16,1,NULL,NULL),
(43,16,3,NULL,NULL),
(44,16,4,NULL,NULL),
(45,17,8,NULL,NULL),
(46,18,5,NULL,NULL),
(47,19,2,NULL,NULL),
(48,19,1,NULL,NULL),
(49,19,4,NULL,NULL),
(50,20,3,NULL,NULL),
(51,20,4,NULL,NULL),
(52,21,2,NULL,NULL),
(53,21,1,NULL,NULL),
(54,22,2,NULL,NULL),
(55,22,4,NULL,NULL),
(56,23,2,NULL,NULL),
(57,23,1,NULL,NULL),
(58,23,4,NULL,NULL),
(59,24,2,NULL,NULL),
(60,24,1,NULL,NULL),
(61,24,3,NULL,NULL),
(62,24,4,NULL,NULL),
(63,25,5,NULL,NULL),
(64,25,3,NULL,NULL),
(65,25,4,NULL,NULL),
(66,26,8,NULL,NULL),
(67,27,2,NULL,NULL),
(68,27,1,NULL,NULL),
(69,27,4,NULL,NULL),
(70,27,9,NULL,NULL),
(71,28,8,NULL,NULL),
(72,29,8,NULL,NULL),
(73,30,8,NULL,NULL),
(74,31,1,NULL,NULL),
(75,31,9,NULL,NULL),
(76,32,5,NULL,NULL),
(77,33,8,NULL,NULL),
(78,34,5,NULL,NULL),
(79,34,10,NULL,NULL),
(80,35,6,NULL,NULL),
(81,35,7,NULL,NULL),
(82,36,5,NULL,NULL),
(83,37,8,NULL,NULL),
(84,37,20,NULL,NULL),
(85,37,14,NULL,NULL),
(86,37,15,NULL,NULL),
(87,37,18,NULL,NULL),
(88,37,16,NULL,NULL),
(89,37,17,NULL,NULL),
(90,37,11,NULL,NULL),
(91,37,19,NULL,NULL),
(92,37,12,NULL,NULL),
(93,37,22,NULL,NULL),
(94,37,13,NULL,NULL),
(95,37,21,NULL,NULL),
(96,38,6,NULL,NULL),
(97,38,2,NULL,NULL),
(98,38,1,NULL,NULL),
(99,38,3,NULL,NULL),
(100,38,4,NULL,NULL),
(101,39,20,NULL,NULL),
(102,39,8,NULL,NULL),
(103,39,17,NULL,NULL),
(104,39,19,NULL,NULL),
(105,39,12,NULL,NULL),
(106,39,21,NULL,NULL),
(107,40,20,NULL,NULL),
(108,40,8,NULL,NULL),
(109,40,12,NULL,NULL),
(110,40,13,NULL,NULL),
(111,41,20,NULL,NULL),
(112,41,14,NULL,NULL),
(113,41,18,NULL,NULL),
(114,41,8,NULL,NULL),
(115,41,17,NULL,NULL),
(116,41,19,NULL,NULL),
(117,41,12,NULL,NULL),
(118,42,15,NULL,NULL),
(119,42,18,NULL,NULL),
(120,42,8,NULL,NULL),
(121,42,17,NULL,NULL),
(122,42,19,NULL,NULL),
(123,42,23,NULL,NULL);
/*!40000 ALTER TABLE `post_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `excerpt` mediumtext DEFAULT NULL,
  `body` text NOT NULL,
  `status` enum('PUBLISHED','DRAFT') NOT NULL DEFAULT 'DRAFT',
  `youtube` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`),
  KEY `posts_user_id_foreign` (`user_id`),
  KEY `posts_category_id_foreign` (`category_id`),
  CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES
(1,1,1,'Servicio de Corte y Mantenimiento de Pasto en Beccar','servicio-de-corte-y-mantenimiento-de-pasto-en-beccar','Servicio de Corte de Pasto en Beccar','<p>Este es un servicio de mantenimiento que se realiza en un domicilio Beccar a una de nuestras primeras clientes, un trabajo &nbsp;con mucho esmero y dedicación en la búsqueda de la completa satisfacción de nuestra cliente. Gracias por elegirnos&nbsp;</p>','PUBLISHED',NULL,'2022-10-25 05:16:11','2022-10-31 02:45:48'),
(2,1,1,'Servicio de Corte y Mantenimiento de Césped en Del Viso','servicio-de-corte-y-mantenimiento-de-cesped-en-del-viso','Cliente en Del Viso Servicio de Corte y Mantenimiento de Césped de Del Viso','<p><strong>Servicio de Corte &nbsp;de Pasto de Del Viso</strong></p><p>Servicio de Corte y Mantenimiento en Del Viso se realiza una vez por semana, se realiza corte, rastrillado limpieza en el lugar</p>','PUBLISHED',NULL,'2022-10-31 03:09:43','2022-10-31 03:15:22'),
(3,1,1,'Servicio de Corte de Pasto en San Martín','servicio-de-corte-de-pasto-en-san-martin','Servicio de Corte de Pasto y Mantenimiento de Jardín en San Martín','<p><strong>Servicio de Corte de Pasto y Mantenimiento de Jardín en San Martín</strong></p><p>El servicio realizado es en la empresa Sinko donde nos ocupamos del mantenimiento y limpieza de jardín.</p>','PUBLISHED',NULL,'2022-11-06 04:20:36','2022-11-06 04:35:10'),
(4,1,1,'Servicio de Corte de Pasto en Liniers','servicio-de-corte-de-pasto-en-liniers','Servicio de Mantenimiento y Corte de Pasto en Liniers','<p><strong>Servicio de Mantenimiento y Corte de Pasto en Liniers</strong></p><p>Este trabajo &nbsp;se realizó una limpieza de sitio, desmalezado, bordeado y posteriormente la poda del pasto.. Gracias al señor Leandro y familia por confiar en nuestro servicio, un placer atenderlos.</p>','PUBLISHED',NULL,'2022-12-04 01:40:43','2022-12-04 02:17:38'),
(5,1,1,'Servicio de Corte de Pasto en Don Torcuato','servicio-de-corte-de-pasto-en-don-torcuato','Servicio de Corte de Pasto en Don Torcuato','<p><strong>Servicio de Corte de Pasto en Don Torcuato</strong></p><p>El Servicio de Corte de Pasto fue realizado en Don Torcuato, se realizo desacubrimiento de bordes, corte de césped, con motoguadaña y corta cesped, fue realizado en don Torcuato&nbsp;</p><p>&nbsp;</p>','PUBLISHED',NULL,'2022-12-24 00:44:34','2022-12-24 00:44:34'),
(6,1,1,'Servicio de Mantenimiento de Jardines','servicio-de-mantenimiento-de-jardines','Servicio de mantenimiento de jardín','<p>Servicio de mantenimiento de jardín de forma quincenal que se hace en el partido de San Martín de la Provincia de Buenos Aires</p>','PUBLISHED',NULL,'2023-02-10 14:55:13','2023-02-10 15:14:47'),
(8,1,1,'Servicio de Jardinería en Beccar','servicio-de-jardineria-en-beccar','Servicio de Jardineria en Beccar','<p>Servicio de jardineria que se realizó en Beccar - Buenos aires - Argentina</p><p>El servicio que se realizó fue la recuperación y una limpieza a fondo de un jardín que no había tenido mantenimiento durante bastante tiempo. Se le emprolijaron las plantas, los arbustos, el cerco y se le realizó un corte de pasto tanto en el jardín exterior como en el patio interior de la casa. Además, se embolso, se retiró todo y se dejó limpio. Para nosotros fue un trabajo muy gratificante al poder ver el resultado final del mismo.</p><p>Agradecemos enormomente a la familia que decidió confiar en nuestra empresa.</p>','PUBLISHED',NULL,'2023-02-17 03:50:38','2023-02-17 05:01:32'),
(9,1,2,'Desmalezado de Terrenos','desmalezado-de-terrenos','Realizamos desmalezados de terrenos y limpieza de obras','<p>Desmalezado de Terrenos<br>Realizamos desmalezados de terrenos y limpieza de obras, corte de césped y pasto. Este trabajo fue realizado en Capital Buenos Aires. Se realizó el desmalezado y limpieza del predio que quedó tal y como lo solicitó nuestro cliente</p>','PUBLISHED',NULL,'2023-02-22 05:33:48','2023-02-22 05:33:48'),
(10,1,1,'Limpieza de Vereda en Vicente López','limpieza-de-vereda-en-vicente-lopez','Limpieza de Vereda en Vicente López','<p>Limpieza de Vereda en Vicente López</p><p>Un servicio de limpieza de calle que brindamos a la empresa de motos GILERA, que se ubicada en Vicente López Provincia de Buenos Aires. El servicio consiste en el corte de maleza y pasto que crece muy desordenadamente justo en la vereda frente a la tienda de la empresa. Nosotros accedemos según su requerimiento.</p>','PUBLISHED',NULL,'2023-02-24 04:15:46','2023-02-24 04:17:04'),
(11,1,3,'Poda y Corte de Cerco en Villa Ballester','poda-y-corte-de-cerco-en-villa-ballester','Poda y Corte de Cerco en Villa Bellester San Martín Buenos Aires','<p><strong>Poda y Corte de Cerco en Villa Bellester San Martín Buenos Aires</strong></p><p>Este servicio de Poda y Corte de cerco se realizó en San Martín - Buenos Aires, el servicio consistió en la poda total de un árbol y la poda genera de todos los cercos de la casa. Agradecemos como siempre la confianza, en nosotros.</p>','PUBLISHED',NULL,'2023-04-03 18:45:41','2023-04-03 19:02:42'),
(12,1,2,'Poda de Árboles, Desmalezado y Limpieza de Terreno en Flores CABA','poda-de-arboles-desmalezado-y-limpieza-de-terreno-en-flores-caba','Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA','<p><strong>Poda de Árboles Desmalezado y Limpieza de Terreno en Flores CABA&nbsp;</strong></p><p>Este Trabajo fue realizado en Flores CABA Buenos Aires Argentina El trabajo que se realizó fue el corte de una palmera, poda de 3 arbustos y el desmalezado del jardín.</p>','PUBLISHED',NULL,'2023-04-15 03:12:01','2023-04-15 04:17:41'),
(13,1,2,'Servicio de Desmalezado de Terreno en San Martín - San Andrés','servicio-de-desmalezado-de-terreno-en-san-martin-san-andres','Desmalezado de Terreno en San Martín: Recuperación de Espacio Jardín','<p>En la zona de San Andrés en San Martín, Buenos Aires, la señora Ivana nos contactó a través de nuestro sitio web para solicitar una cotización. Previamente, la visitamos para evaluar el trabajo y proporcionarle un presupuesto. Dos días después, llevamos a cabo la recuperación y limpieza del espacio, transformándolo en un lugar más ordenado y habitable. Agradecemos la confianza que nos brindó Ivana y esperamos haber cumplido con sus expectativas</p>','PUBLISHED',NULL,'2023-09-07 15:18:13','2023-09-07 16:03:53'),
(14,1,1,'Servicio de Corte de Pasto en Alberti','servicio-de-corte-de-pasto-en-alberti','Hoy queremos compartir con ustedes el resultado de nuestro último servicio de corte de pasto para nuestro apreciado cliente Marco en Alberti, Buenos Aires.','<p>¡Un jardín bien cuidado es un jardín feliz! Hoy queremos compartir con ustedes el resultado de nuestro último servicio de corte de pasto para nuestro apreciado cliente Marco en Alberti, Buenos Aires. Estamos encantados de haber tenido la oportunidad de embellecer su espacio exterior.</p><p>Nos esmeramos al máximo para dejar cada rincón impecable. Sabemos lo importante que es mantener un espacio verde que transmita tranquilidad y armonía, y nos enorgullecemos de haber logrado ese objetivo una vez más.</p><p>¿Necesitas un cambio en tu jardín? No dudes en contactarnos para agendar tu próximo servicio de corte de pasto. Estamos aquí para convertir tu espacio exterior en un lugar que te inspire y relaje.</p><p>¡Gracias por confiar en nosotros, Marco! 💚🌱 #CorteDePasto #JardínFeliz #AlbertiVerde</p>','PUBLISHED',NULL,'2023-09-15 15:17:43','2023-09-15 19:12:27'),
(15,1,1,'Servicio de Corte de Pasto y Desmalezado en San Fernando - Buenos Aires','servicio-de-corte-de-pasto-y-desmalezado-en-san-fernando-buenos-aires','para la señora Josefina en San Fernando, Buenos Aires. Trabajo comprendió corte de césped, desmalezado, retiro de yuyos y corte de cerco en su terreno.','<p>Saludos a todos, queremos compartir el reciente trabajo reciente que realizamos para la señora Josefina en San Fernando, Buenos Aires. Trabajo comprendió corte de césped, desmalezado, retiro de yuyos y corte de cerco en su terreno.</p><p>Nos complace haber podido brindar un servicio completo que dejó el jardín de la señora Josefina en impecables condiciones. Cada detalle fue atendido con esmero y profesionalismo. Si estás buscando una solución integral para tu jardín, no dudes en contactarnos.</p><p>Además de la labor de corte y desmalezado, nos aseguramos de que ningún rincón quedara sin atención. El retiro de yuyos y el cuidado del cerco fueron parte fundamental de este proyecto.</p><p>Agradecemos sinceramente a la señora Josefina por confiar en nosotros y permitirnos ser parte de la renovación de su espacio exterior. Esperamos seguir embelleciendo más jardines en San Fernando y sus alrededores.</p><p>Si deseas más información sobre nuestros servicios, no dudes en comunicarte con nosotros. Estamos aquí para hacer realidad tus ideas de jardinería.</p>','PUBLISHED',NULL,'2023-09-21 17:51:31','2023-09-21 17:54:19'),
(16,1,1,'Servicio de Corte de Pasto y Limpieza en Ingeniero Maschwitz','servicio-de-corte-de-pasto-y-limpieza-en-ingeniero-maschwitz',NULL,'<p>En Ingeniero Maschwitz, Buenos Aires, realizamos un servicio de corte de pasto, limpieza a fondo y poda de enredaderas que transformó por completo el espacio. Miguel y Graciela, nuestros clientes en el encantador barrio cerrado Maschwitz Country Club, quedaron encantados con el resultado. Su jardín ahora luce simplemente espectacular.</p><p>Estamos felices de haber podido superar sus expectativas y brindarles un espacio que refleja su esencia. ¡Gracias por confiar en nuestro equipo!</p><p>Si vos también querés transformar tu jardín y darle un toque especial, ¡contactanos! Estamos aquí para hacer realidad tus ideas.</p><p>#Jardinería #TransformaciónDeEspacios #MaschwitzCountryClub #ClientesFelices #CorteDePasto #LimpiezaAProfundidad #Enredaderas #IngenieroMaschwitz #BuenosAires #JardínImpresionante</p>','PUBLISHED',NULL,'2023-09-28 19:25:27','2023-09-28 19:25:27'),
(17,1,4,'Servicio de Poda de Altura en CABA','servicio-de-poda-de-altura-en-caba','mensaje test','<p>Poda de altura realizada en Caba - Buenos Aires - Argentina. Servicio solicitado por nuestro cliente la señora Norma quien ahora podrá disfrutar de su hogar sin preocupaciones, sabiendo que su entorno está protegido. Valoramos la confianza que depositó en nosotros y estamos agradecidos por la oportunidad de servirle.</p><p>Si Usted también necesita una poda de altura que garantice la seguridad de tu hogar, ¡contáctanos hoy mismo!</p>','PUBLISHED',NULL,'2023-10-08 05:30:32','2023-10-08 06:10:02'),
(18,1,2,'Servicio de Desmalezado de Terreno en Matadero CABA','servicio-de-desmalezado-de-terreno-en-matadero-caba','Servicio de Desmalezado y Limpieza de Terreno en la Zona de Matadero CABA','<p>🌿 ¡Transformamos un terreno en Matadero, CABA, de un estado de hierba alta y maleza a un espacio limpio y listo para su próximo propósito! 🌿</p><p>✅ Enfrentamos el desafío de un terreno descuidado y lo convertimos en un lugar impecable. Nuestro Servicio de Desmalezado cuenta con profesionales expertos y equipos de alta calidad para lograr resultados excepcionales.</p><p>💼 Si tenías dificultades para visualizar el potencial de tu terreno, ¡nosotros lo hacemos realidad! Ya sea para construcción, renovación o simplemente para mantener un aspecto pulcro, tenemos la experiencia necesaria.</p><p>🌾 Más allá de la estética, el desmalezado adecuado promueve un ambiente más saludable y seguro. No subestimes el impacto positivo que puede tener en tu espacio.</p><p>👷‍♂️ Nuestro equipo altamente capacitado se enorgullece de su trabajo y garantiza resultados de alta calidad en cada proyecto. Transformamos terrenos para que cumplan su propósito de la mejor manera posible.</p><p>🗓️ ¡Si tu terreno necesita una renovación similar, agenda una cita hoy mismo!&nbsp;</p><p>#Desmalezado #Terreno #MataderoCABA #LimpiezaDeTerrenos #Transformación</p>','PUBLISHED',NULL,'2023-10-15 19:40:30','2023-10-15 19:40:30'),
(19,1,1,'Servicio de Corte de Pasto en Villa Luzuriaga','servicio-de-corte-de-pasto-en-villa-luzuriaga','Servicio de Corte de Pasto en Villa Luzuriaga','<p>🌿 <strong>Transformando tu Jardín en un Paraíso Verde: Nuestro Servicio de Corte de Pasto en Villa Luzuriaga, Buenos Aires</strong> 🌿</p><p>&nbsp;</p><p>Queremos expresar nuestro más sincero agradecimiento por confiar en nosotros para cuidar de tu precioso jardín en Villa Luzuriaga, Buenos Aires. Fue un honor para nuestro equipo llevar a cabo el servicio de corte de pasto y transformar tu espacio exterior en un verdadero paraíso verde.</p><p>Desde el momento en que llegamos, nos sumergimos en la tarea con dedicación y pasión. Cada hoja cortada fue un paso más hacia la creación de un césped impecable y exuberante que complementara la belleza de tu hogar. Nos esforzamos por cada detalle, asegurándonos de que cada rincón recibiera la atención que merece.</p><p>La satisfacción de nuestros clientes es nuestra mayor motivación, y ver la sonrisa en tu rostro al ver el resultado final es lo que nos impulsa a superar expectativas una y otra vez. Nos alegra profundamente haber contribuido a la creación de un espacio al aire libre donde puedas relajarte, compartir momentos con tus seres queridos y disfrutar de la naturaleza en su máximo esplendor.</p><p>Queremos que sepas que nuestro compromiso contigo va más allá de este servicio. Estamos aquí para apoyarte en el cuidado continuo de tu jardín y para asegurarnos de que siempre refleje tu estilo y personalidad únicos.</p><p>Gracias nuevamente por permitirnos ser parte de tu historia verde en Villa Luzuriaga. Esperamos tener la oportunidad de servirte nuevamente en el futuro.</p>','PUBLISHED',NULL,'2024-01-28 19:49:50','2024-01-28 19:58:22'),
(20,1,1,'Servicio de Mantenimiento de Jardines - San Martín','servicio-de-mantenimiento-de-jardines-san-martin','Servicio de Mantenimiento de Jardines - San Martín','<p><strong>Servicio de Mantenimiento de Jardines - San Martín</strong></p><p>&nbsp;</p><p>🌿 <strong>¡Manteniendo la Belleza Natural en San Martín, Buenos Aires!</strong> 🌿</p><p>¡Hola, amantes de la naturaleza! Hoy queremos compartir con ustedes una historia de transformación verde en San Martín, Buenos Aires. Nos complace presentarles el excepcional trabajo de mantenimiento realizado para nuestra apreciada cliente, Mary. 💚✨</p><p><strong>¿Quién es Mary?</strong></p><p>Mary es una entusiasta del verde, pero con un estilo de vida ocupado, necesitaba ayuda para mantener su jardín tan hermoso como siempre lo había soñado. Confío en nosotros para hacer posible esa visión.</p><p><strong>El Mantenimiento:</strong></p><p>Con dedicación y cuidado experto, nos embarcamos en la misión de mantener el jardín de Mary en su máximo esplendor. Cada visita fue una oportunidad para cuidar cada planta, cada rincón verde, con el mismo amor y pasión que si fuera nuestro propio jardín.</p><ul><li><strong>Podas Precisas:</strong> Realizamos podas meticulosas para mantener la forma y la salud de cada planta, promoviendo su crecimiento y vitalidad.</li><li><strong>Cuidado del Césped:</strong> Nos aseguramos de que el césped de Mary estuviera siempre perfectamente cortado y saludable, listo para disfrutar en cualquier momento.</li><li><strong>Atención Personalizada:</strong> Escuchamos las necesidades específicas de Mary y adaptamos nuestro servicio de mantenimiento para satisfacer sus expectativas y superarlas.</li></ul><p><strong>El Resultado:</strong></p><p>El jardín de Mary se convirtió en un reflejo de su amor por la naturaleza y su dedicación al cuidado del medio ambiente. Cada vez que ella salía al jardín, encontraba un oasis de paz y belleza, gracias al mantenimiento regular y profesional que le proporcionamos.</p><p><strong>¿Quieres un Jardín Siempre Radiante?</strong></p><p>Si buscas un servicio de mantenimiento de jardines que te permita disfrutar de la belleza de tu espacio exterior sin preocupaciones, ¡estamos aquí para ayudarte! Nuestro equipo está comprometido a mantener la belleza natural de tu jardín, para que puedas relajarte y disfrutar al máximo.</p><p>¡Contáctanos hoy mismo y descubre cómo podemos mantener tu jardín siempre radiante!</p>','PUBLISHED',NULL,'2024-01-30 14:10:39','2024-02-01 05:19:03'),
(21,1,1,'Servicio de Corte y Mantenimiento de Césped en Villa Mitre Buenos Aires Capital','servicio-de-corte-y-mantenimiento-de-cesped-en-villa-mitre-buenos-aires-capital','Servicio de Corte y Mantenimiento de Césped en Villa Mitre - Buenos Aires Capital. ofrecemos un servicio profesional de corte y mantenimiento de césped','<p><strong>Servicio de Corte y Mantenimiento de Césped en Villa Mitre - Buenos Aires Capital.</strong></p><p>¿Quieres que tu jardín luzca impecable esta temporada? ¡Nosotros te ayudamos! En Villa Mitre, Buenos Aires Capital, ofrecemos un servicio profesional de corte de césped que transformará tu espacio exterior en un oasis de verdor y frescura. #Jardinería #CorteDeCésped #VillaMitre</p><p>Nuestro equipo de expertos se especializa en el corte preciso y cuidadoso del césped, utilizando herramientas de última generación para garantizar un resultado impecable. Nos encargamos de mantener la altura adecuada del césped para promover su salud y belleza. #CuidadoDelCésped #ServicioProfesional</p><p>Entendemos que cada jardín es único, por lo que ofrecemos un servicio personalizado adaptado a tus necesidades y preferencias. Ya sea que tengas un pequeño patio trasero o un extenso terreno, estamos aquí para ayudarte a mantenerlo en perfectas condiciones durante todo el año. #JardinesPersonalizados #ServicioALaMedida</p><p>¡No esperes más para tener el césped de tus sueños! Contáctanos hoy mismo para obtener más información sobre nuestro servicio de corte de césped en Villa Mitre, Buenos Aires Capital. Tu jardín te lo agradecerá. #BuenosAires</p>','PUBLISHED',NULL,'2024-03-17 16:17:16','2024-06-10 00:48:46'),
(22,1,1,'Servicio de Mantenimiento de Areas Verdes Para Empresas','servicio-de-mantenimiento-de-areas-verdes-para-empresas','Realizamos Servicio de Mantenimiento de Areas Verdes Para Empresas - Industrias Zeta','<p>🌱 ¡Mantén tus espacios verdes impecables con nuestro servicio de Mantenimiento y Corte de Pasto en Don Torcuato! 🌱</p><p>En&nbsp;<strong> Industrias Zeta</strong>, entendemos la importancia de tener áreas verdes bien cuidadas para crear un entorno laboral agradable y productivo. Es por eso que nos especializamos en ofrecer un servicio completo de mantenimiento y corte de pasto para empresas en Don Torcuato.</p><p>¿Qué incluye nuestro servicio?</p><p><strong>Corte de Césped Profesional:</strong> Nuestro equipo de jardineros expertos se encarga de cortar el césped de manera uniforme y precisa, utilizando las mejores herramientas y técnicas para garantizar un resultado impecable.</p><p><strong>Podado de Borduras y Áreas Verdes:</strong> Además del corte de césped, nos ocupamos del podado de borduras y áreas verdes para mantener todo el entorno limpio, ordenado y seguro.</p><p><strong>Retiro de Residuos:</strong> Después de cada sesión de mantenimiento, nos aseguramos de recoger y eliminar todos los residuos generados, dejando tus espacios verdes impecables y listos para ser disfrutados.</p><p><strong>Programación Personalizada:</strong> Trabajamos contigo para establecer un programa de mantenimiento personalizado que se adapte a tus necesidades específicas y al tamaño de tus áreas verdes.</p><p>¿Por qué elegirnos?</p><ul><li>Experiencia y Profesionalismo: Contamos con un equipo altamente capacitado y con experiencia en el mantenimiento de áreas verdes para empresas en Don Torcuato.</li><li>Resultados Garantizados: Utilizamos técnicas y herramientas de última generación para asegurar resultados de calidad en cada sesión de mantenimiento.</li><li>Atención al Cliente: Nos dedicamos a entender tus necesidades y preocupaciones para ofrecerte un servicio personalizado y de calidad.</li></ul><p>¡Confía en nosotros para mantener tus espacios verdes en perfectas condiciones durante todo el año! Contáctanos hoy mismo para obtener más información y solicitar un presupuesto sin compromiso.</p><p>#MantenimientoDeÁreasVerdes #CorteDePasto #DonTorcuato #JardineríaEmpresarial 🌱✂️💼</p>','PUBLISHED',NULL,'2024-06-10 01:15:41','2024-06-10 01:25:39'),
(23,1,1,'Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-pilar','Servicio de Mantenimiento de Areas Verdes Para Empresas en Pilar - ULMA Andamios y Encofrados','<p>🌿 ¡Embellece tu entorno empresarial en Pilar con nuestro servicio de Mantenimiento de Áreas Verdes y Corte de Pasto! 🌿</p><p>En<strong> ULMA Andamios y Encofrados Argentina</strong>, nos enorgullece ofrecer soluciones integrales de cuidado y embellecimiento de espacios verdes para empresas en la próspera ciudad de Pilar. Sabemos que un entorno empresarial bien cuidado no solo mejora la estética, sino que también eleva el ánimo de tus empleados y proyecta una imagen positiva a clientes y visitantes.</p><p>¿Qué ofrecemos?</p><p><strong>Corte de Pasto Profesional:</strong> Nuestro equipo de jardineros expertos se encarga de mantener tu césped impecablemente cortado, utilizando equipos de última generación para asegurar un acabado uniforme y de calidad.</p><p><strong>Mantenimiento Integral:</strong> Más allá del corte de pasto, nos ocupamos de todas las tareas necesarias para mantener tus áreas verdes en perfecto estado durante todo el año. Desde el podado de arbustos hasta la limpieza de parterres y la instalación de sistemas de riego automatizado, estamos aquí para cubrir todas tus necesidades de mantenimiento.</p><p><strong>Programación Flexible:</strong> Trabajamos contigo para establecer un programa de mantenimiento personalizado que se adapte a tus horarios y necesidades específicas, garantizando que tus espacios verdes siempre luzcan impecables.</p><p><strong>Compromiso con la Excelencia:</strong> En <strong>Altoparque</strong> nos esforzamos por ofrecer resultados de la más alta calidad en cada proyecto que emprendemos. Nos comprometemos a utilizar técnicas sostenibles y respetuosas con el medio ambiente para preservar la belleza natural de Pilar.</p><p>¿Por qué elegirnos?</p><ul><li>Experiencia y Profesionalismo: Contamos con un equipo de jardineros altamente capacitados y con años de experiencia en el cuidado de áreas verdes para empresas en Pilar.</li><li>Atención Personalizada: Nos dedicamos a entender tus necesidades específicas y a ofrecerte soluciones a medida que se ajusten a tu presupuesto y visión.</li><li>Resultados Garantizados: Utilizamos las mejores técnicas y herramientas disponibles en el mercado para asegurar resultados duraderos y de calidad en cada proyecto que realizamos.</li></ul><p>¡No esperes más para transformar el entorno de tu empresa en Pilar en un oasis verde de belleza y productividad! Contáctanos hoy mismo para obtener más información y solicitar un presupuesto sin compromiso.</p><p>#MantenimientoDeÁreasVerdes #CorteDePasto #Pilar #JardineríaEmpresarial #MejoraDelEntorno 🌿✂️💼</p>','PUBLISHED',NULL,'2024-06-10 02:34:58','2024-08-10 14:46:04'),
(24,1,1,'Servicio de Mantenimiento de Áreas Verdes para Empresas en Buenos Aires','servicio-de-mantenimiento-de-areas-verdes-para-empresas-en-buenos-aires','Servicio de Mantenimiento de Áreas Verdes en Buenos Aires  está diseñado específicamente para empresas que buscan espacios exteriores impecables durante todo el año.','<p><strong>🌿 Servicio de Mantenimiento de Áreas Verdes para Empresas en Buenos Aires 🌿</strong></p><p>En Buenos Aires, mantener las áreas verdes en óptimas condiciones es clave para cualquier empresa que quiera proyectar una imagen profesional y amigable con el medio ambiente. Nuestro <strong>Servicio de Mantenimiento de Áreas Verdes</strong> está diseñado específicamente para empresas que buscan <strong>espacios exteriores impecables</strong> durante todo el año. 🍃</p><p>Contamos con un equipo de expertos en jardinería y paisajismo que se encargará de cada detalle, desde el corte de césped hasta la poda de arbustos y el cuidado de plantas. Nos aseguramos de que tus áreas verdes no solo sean estéticamente agradables, sino también saludables y sostenibles. 🌻🌳</p><p>Además, ofrecemos un plan personalizado que se adapta a las necesidades y al presupuesto de tu empresa. Ya sea que necesites mantenimiento semanal, quincenal o mensual, estamos aquí para ayudarte. ¡Nos encargamos de todo para que tú puedas concentrarte en lo que realmente importa! ✅</p><p>En nuestra empresa, utilizamos <strong>productos ecológicos</strong> que respetan el medio ambiente y aseguran que tus espacios verdes contribuyan a un entorno más saludable. 🌎</p><p>¿Por qué elegirnos? Porque <strong>garantizamos calidad, puntualidad y un servicio a medida</strong> que hará que tus áreas verdes destaquen frente a la competencia. Ya sea en oficinas, parques industriales o complejos empresariales, nuestro equipo está listo para transformar y mantener tus espacios exteriores. 💪</p><p>Contáctanos hoy mismo y descubre cómo podemos hacer que las áreas verdes de tu empresa en Buenos Aires luzcan espectaculares todo el año. ¡Tu entorno lo merece! 📞🌟</p><p>#MantenimientoDeJardines #ÁreasVerdes #EmpresasBA #ServicioProfesional #Paisajismo #MedioAmbiente #BuenosAires #JardineríaEmpresarial #Sostenibilidad</p>','PUBLISHED',NULL,'2024-08-31 19:42:44','2024-08-31 19:44:49'),
(25,1,2,'Servicio de Desmalezado y Limpieza de Jardín en Maschwitz','servicio-de-desmalezado-y-limpieza-de-jardin-en-maschwitz','Servicio de Desmalezado y Limpieza de Jardín Nos especializamos en el desmalezado rápido y eficiente, eliminando toda la maleza y plantas no deseadas que puedan afectar la estética y salud de tu jardín. Con un equipo de expertos en jardinería, garantizamos que tu espacio verde quedará limpio, ordenado y libre de cualquier obstrucción','<p><strong>🌿 Servicio de Desmalezado y Limpieza de Jardín en Maschwitz 🌿</strong></p><p>Si tu jardín en Maschwitz necesita una renovación o una limpieza profunda, ¡estás en el lugar correcto! Nuestro <strong>Servicio de Desmalezado y Limpieza de Jardín</strong> está diseñado para dejar tus espacios exteriores impecables y listos para disfrutar. 🌳✨</p><p>Nos especializamos en el <strong>desmalezado rápido y eficiente</strong>, eliminando toda la maleza y plantas no deseadas que puedan afectar la estética y salud de tu jardín. Con un equipo de expertos en jardinería, garantizamos que tu espacio verde quedará limpio, ordenado y libre de cualquier obstrucción. 🍂🌱</p><p>El desmalezado no solo mejora el aspecto de tu jardín, sino que también previene plagas y enfermedades que pueden dañar tus plantas. Además, realizamos <strong>limpieza de hojas, ramas secas y escombros</strong> para asegurar que tu jardín luzca en perfectas condiciones en todo momento. 🧹🌿</p><p>Ya sea para casas particulares, <strong>empresas</strong> o <strong>barrios cerrados</strong> en Maschwitz, contamos con la experiencia y herramientas necesarias para brindarte un servicio de calidad. Nos adaptamos a tus necesidades y te ofrecemos <strong>presupuestos personalizados</strong> que se ajusten a tu jardín y al tamaño del trabajo. ✅</p><p>¿Por qué confiar en nosotros? Porque trabajamos de manera rápida, eficiente y siempre cuidando el medio ambiente. 💪🌎</p><p>Contáctanos hoy mismo para obtener más información y deja que nuestro equipo profesional transforme tu jardín en un espacio limpio, cuidado y agradable. ¡Tu jardín en Maschwitz se merece lo mejor! 📞🌟</p><p>#DesmalezadoMaschwitz #LimpiezaDeJardín #JardineríaMaschwitz #MantenimientoDeJardines #MaschwitzVerde #ServicioProfesional #ÁreasVerdes</p>','PUBLISHED',NULL,'2024-09-30 01:49:34','2024-10-06 16:55:13'),
(26,1,4,'Poda de Altura en San Martín','poda-de-altura-en-san-martin','Poda de Altura en San Martín','<h2>🌳<strong> Poda de Altura en San Martín: Servicios Profesionales y Seguros</strong></h2><h3>¿Buscás un servicio de <strong>poda de altura en San Martín</strong> confiable, seguro y profesional?</h3><p>En este artículo te contamos todo lo que necesitás saber sobre este servicio esencial para el cuidado de árboles altos, jardines y espacios verdes en la zona de San Martín, Buenos Aires.</p><h3>✅ ¿Qué es la poda de altura?</h3><p>La <strong>poda de altura</strong> consiste en cortar y dar forma a ramas de árboles ubicados a gran altura. Este trabajo requiere experiencia, herramientas adecuadas y, sobre todo, medidas de seguridad específicas. Se realiza por motivos de:</p><p>Seguridad (evitar caída de ramas sobre casas, autos o personas)</p><p>Mantenimiento estético</p><p>Salud del árbol</p><p>Prevención de obstrucciones con cables eléctricos</p><h3>🛠️ Servicios de poda de altura en San Martín</h3><p>En San Martín, contamos con cuadrillas especializadas en:</p><p><strong>Poda correctiva y de formación</strong></p><p><strong>Retiro de ramas peligrosas</strong></p><p><strong>Desrame cerca de tendidos eléctricos</strong></p><p><strong>Mantenimiento de arbolado urbano y privado</strong></p><p>Nuestros servicios cumplen con normativas municipales y se realizan con seguros de responsabilidad civil.</p><h3>📍 ¿Por qué elegirnos para la poda de altura en San Martín?</h3><p>Más de 10 años de experiencia</p><p>Personal capacitado en trabajos en altura</p><p>Equipos certificados (arneses, escaleras, motosierras telescópicas)</p><p>Rápida respuesta en barrios como Villa Lynch, San Andrés, José León Suárez y Billinghurst</p><h3>🟢 Beneficios de una poda de altura bien realizada</h3><p>Mejora la salud del árbol</p><p>Evita accidentes y cortes de luz</p><p>Aumenta el valor estético de tu jardín</p><p>Facilita el crecimiento controlado de especies arbóreas</p><h3>📞 Contactanos para poda de altura en San Martín</h3><p>¿Necesitás un presupuesto sin compromiso?<br>Llamanos o escribinos por WhatsApp. Atendemos urgencias 24/7 y trabajamos tanto para particulares como para empresas y municipios.</p><p>👉 <strong>Teléfono / WhatsApp</strong>: 1138872953<br>👉 <strong>Email</strong>: info@serviciodejardineria.com.ar<br>👉 <strong>Ubicación</strong>: San Martín, Buenos Aires</p><h3>&nbsp;</h3><p>Poda de árboles en altura San Martín</p><p>Servicio de poda en San Martín</p><p>Empresas de poda profesional en altura</p><p>Trabajos de poda de riesgo San Martín</p><p>Poda segura con arnés y motosierras</p>','PUBLISHED',NULL,'2025-06-18 15:01:35','2025-06-18 15:01:35'),
(27,1,5,'Corte de Pasto con Tractor Cortacésped para Empresas','corte-de-pasto-con-tractor-cortacesped-para-empresas','Corte de Pasto con Tractor Cortacésped para Empresas: Soluciones Profesionales y Rápidas','<h2><strong>Corte de Pasto con Tractor Cortacésped para Empresas: Soluciones Profesionales y Rápidas</strong></h2><p>¿Tu empresa necesita mantener amplios espacios verdes en condiciones impecables? Nuestro servicio de <strong>corte de pasto con tractor cortacésped para empresas</strong> está pensado para cubrir grandes superficies con máxima eficiencia, seguridad y puntualidad.</p><h3>✅ ¿En qué consiste el corte de pasto con tractor cortacésped?</h3><p>El <strong>tractor cortacésped</strong> es ideal para terrenos de gran tamaño que requieren mantenimiento frecuente. A diferencia del corte manual, esta maquinaria permite:</p><p>Mayor rapidez de ejecución</p><p>Terminaciones prolijas</p><p>Menor impacto sobre el suelo</p><p>Ahorro de tiempo y costos operativos</p><p>Ideal para predios industriales, campos deportivos, centros logísticos y espacios verdes corporativos.</p><h3>🛠️ Servicios ofrecidos</h3><p>Ofrecemos <strong>servicio de corte de pasto con tractor para empresas</strong> con maquinaria moderna y operarios capacitados.</p><p>Nuestros trabajos incluyen:</p><p>Corte de pasto con tractores cortacésped profesionales</p><p>Desmalezado general de grandes extensiones</p><p>Mantenimiento programado (semanal / mensual)</p><p>Servicio express para eventos o auditorías</p><p>Limpieza y recolección posterior del residuo verde (opcional)</p><h3>🏢 ¿A quiénes está dirigido este servicio?</h3><p>✅ Empresas de logística y transporte<br>✅ Fábricas e industrias<br>✅ Parques industriales<br>✅ Empresas constructoras<br>✅ Clubes de campo y barrios privados<br>✅ Predios gubernamentales o municipales</p><h3>📍 Zona de cobertura</h3><p>Realizamos <strong>corte de pasto con tractor para empresas</strong> en todo el AMBA y zonas cercanas:</p><p>San Martín</p><p>Tres de Febrero</p><p>Escobar</p><p>Pilar</p><p>Moreno</p><p>Malvinas Argentinas</p><p>Zona Norte y Oeste GBA</p><h3>💼 ¿Por qué elegirnos?</h3><p>Más de 10 años de experiencia</p><p>Personal asegurado y capacitado</p><p>Maquinaria propia (tractores cortacésped, desmalezadoras, bordeadoras)</p><p>Puntualidad y cumplimiento</p><p>Presupuestos competitivos para empresas</p><h3>📞 Solicitá tu presupuesto sin cargo</h3><p>Contactanos hoy y coordinamos una visita técnica a tu predio para evaluar el trabajo necesario.</p><p>📱 <strong>Teléfono / WhatsApp</strong>: 1138872953 (enviar whatsapp)<br>📧 <strong>Email</strong>: info@serviciodejardineria.com.ar<br>🌐 <strong>Web</strong>: https://altoparque.com</p><h3>&nbsp;</h3><p>Corte de pasto con tractor cortacésped</p><p>Mantenimiento de césped para empresas</p><p>Servicio de corte de pasto con maquinaria</p><p>Corte de césped profesional en predios industriales</p><p>Empresa de corte de pasto AMBA</p>','PUBLISHED',NULL,'2025-06-18 15:20:19','2025-06-18 15:28:43'),
(28,1,4,'Servicio de Poda de Altura en Caballito, CABA','servicio-de-poda-de-altura-en-caballito-caba','Servicio de Poda de Altura en Caballito','<h2><strong>🌳 Servicio de Poda de Altura en Caballito, CABA – Seguro, Profesional y Rápido</strong></h2><p>¿Buscás un <strong>servicio de poda de altura en Caballito</strong> que sea confiable, profesional y cumpla con las normas del Gobierno de la Ciudad? En zonas urbanas como Caballito, la poda de árboles altos requiere experiencia, permisos y máxima seguridad.</p><h3>✅ ¿Qué incluye nuestro servicio de poda de altura?</h3><p>La poda de altura es fundamental para:</p><p>Evitar caídas de ramas sobre casas, autos o personas</p><p>Despejar luminarias y cables de alta tensión</p><p>Mantener la salud del árbol</p><p>Cumplir con normas municipales</p><p>En Caballito, trabajamos con <strong>equipos de poda autorizados</strong>, técnicos especializados y herramientas certificadas.</p><h3>🛠️ ¿Cómo trabajamos?</h3><p>Nuestros servicios en Caballito incluyen:</p><p><strong>Poda correctiva, de formación y de mantenimiento</strong></p><p><strong>Corte y retiro de ramas secas o peligrosas</strong></p><p><strong>Poda con arnés, motosierras telescópicas y elevadores hidráulicos</strong></p><p><strong>Trámite de permiso de poda en CABA</strong> (si lo necesitás)</p><p>Además, garantizamos limpieza total posterior al trabajo.</p><h3>📍 Zona de cobertura: Caballito y alrededores</h3><p>Atendemos en todo el barrio de <strong>Caballito</strong>, incluyendo zonas como:</p><p>Parque Centenario</p><p>Primera Junta</p><p>Av. Rivadavia, Av. La Plata y Av. Pedro Goyena</p><p>Plaza Irlanda</p><p>Barrio Inglés</p><p>También damos servicio en barrios cercanos: Almagro, Flores, Villa Crespo y Palermo.</p><h3>🟢 ¿Por qué elegirnos?</h3><p>Personal con seguro</p><p>Más de 10 años de experiencia</p><p>Trabajos habilitados según normativa porteña</p><p>Equipamiento de última generación</p><p>Atención personalizada y presupuestos sin cargo</p><h3>📞 Contactanos</h3><p>Pedí tu <strong>presupuesto gratuito</strong> hoy mismo. Atendemos urgencias por ramas caídas y coordinamos podas programadas.</p><p>📱 WhatsApp / Teléfono: 1138872953 (ENVIAR WHATSAPP)<br>📧 Email: info@serviciodejardineira.com.ar<br>📍 Localizados en CABA – Atendemos todo Caballito y alrededores</p><h3>&nbsp;</h3><p>Poda de altura en Caballito</p><p>Servicio de poda profesional en CABA</p><p>Poda de árboles altos en barrios porteños</p><p>Empresa de poda en altura habilitada en Ciudad de Buenos Aires</p><p>Podadores con seguro en Caballito</p>','PUBLISHED',NULL,'2025-06-18 15:47:48','2025-06-18 15:47:48'),
(29,1,4,'Servicio Poda de Altura para Empresas','servicio-poda-de-altura-para-empresas','Servicio Poda de Altura para Empresas','<h2><strong>Servicio Poda de Altura para Empresas</strong></h2><p>En el mundo corporativo, mantener los espacios exteriores seguros, limpios y visualmente atractivos es una prioridad. Nuestro <strong>servicio de poda de altura para empresas</strong> está diseñado para cubrir esa necesidad de forma profesional, eficiente y segura.</p><p>La poda de altura es una tarea especializada que requiere experiencia, equipos adecuados y conocimiento técnico. En entornos empresariales, donde la seguridad del personal y la imagen corporativa son esenciales, contar con un equipo certificado es clave.</p><p>Realizamos <strong>poda de árboles altos</strong>, limpieza de ramas secas o peligrosas, despeje de líneas eléctricas y control de copa para prevenir riesgos. Nuestros servicios se adaptan a oficinas, parques industriales, centros comerciales, hoteles, hospitales y todo tipo de instalaciones corporativas.</p><p>¿Por qué elegirnos?<br>✅ Contamos con personal capacitado en trabajos verticales y manejo de motosierras.<br>✅ Utilizamos equipos certificados y seguros de responsabilidad civil.<br>✅ Ofrecemos planes periódicos de mantenimiento.<br>✅ Cumplimos con normas ambientales y de seguridad laboral.</p><p>Los árboles mal cuidados pueden provocar caídas de ramas, daños materiales e incluso accidentes. Por eso, muchas empresas optan por <strong>programar podas preventivas</strong> y así garantizar la seguridad de sus empleados y clientes.</p><p>Además del aspecto funcional, la poda también mejora la estética del entorno corporativo, proyectando una imagen de orden y profesionalismo.</p><p>Ofrecemos presupuestos gratuitos y asesoría técnica para determinar el tipo de poda que necesita cada espacio.</p><p>Si tu empresa busca un servicio confiable, con experiencia y enfoque ambiental, contáctanos. Nos especializamos en <strong>poda de altura para empresas con estándares de calidad y seguridad certificados</strong>.</p><p>📍 Atención en toda la ciudad y zonas industriales.<br>📅 Disponibilidad para trabajos urgentes o programados.</p><p><strong>Solicita tu cotización hoy mismo y asegura tus áreas verdes con profesionales.</strong></p><p>#PodaDeAltura #PodaEmpresarial #ServiciosEmpresariales #MantenimientoDeÁrboles #PodaProfesional #ÁreasVerdes #PodaSegura #TrabajosEnAltura #PodaConAltura #EspaciosCorporativos #ServiciosParaEmpresas #PodaIndustrial #PodaSegura #ImagenEmpresarial #JardineríaProfesional #SeguridadEmpresarial #RiesgoCero #MantenimientoCorporativo #CuidadoAmbiental #ManejoDeÁrboles #PodaCertificada #ServiciosUrbanos #PodaTécnica #PodaEnAlturaEmpresas #VerdeCorporativo</p>','PUBLISHED',NULL,'2025-06-30 13:32:56','2025-06-30 13:54:15'),
(30,1,4,'Servicio de Poda de Altura en San Martín','servicio-de-poda-de-altura-en-san-martin','Servicio de Poda de Altura en San Martín','<h2>Servicio de Poda de Altura en San Martín</h2><p>¿Vivís o trabajás en <strong>San Martín</strong> y necesitás un <strong>servicio de poda de altura confiable y profesional</strong>? Somos especialistas en trabajos seguros en altura, con años de experiencia atendiendo hogares, empresas y organismos públicos de la zona.</p><p>La poda de altura no es solo cuestión estética: se trata de <strong>prevenir riesgos</strong>, cuidar la salud del árbol y garantizar la seguridad de personas y estructuras cercanas. En San Martín, donde el arbolado urbano es abundante, este servicio es fundamental.</p><p>Enfrentar ramas que crecen cerca de cables, techos o carteles no es algo para improvisar. Nuestro equipo está capacitado para <strong>trabajar en altura con técnicas seguras</strong>, ya sea mediante escalada, plataformas o grúas según la necesidad del terreno.</p><h3>¿Qué ofrecemos?</h3><p>🌿 Poda correctiva y preventiva<br>🌳 Control de copa y reducción de volumen<br>⚠️ Retiro de ramas secas o peligrosas<br>🔌 Despeje de luminarias y tendidos eléctricos<br>🧹 Limpieza final y retiro de residuos<br>📋 Informes técnicos si se requieren habilitaciones</p><p>Nos destacamos por brindar un trato profesional, cumplir los tiempos pactados y trabajar con total respeto por el entorno natural y urbano. Nuestros clientes en <strong>Villa Maipú, José León Suárez, Villa Ballester y todo San Martín</strong> avalan nuestra calidad.</p><p>Además, ofrecemos <strong>presupuestos gratuitos</strong>, visitas técnicas sin compromiso y <strong>atención urgente ante caídas o tormentas</strong>.</p><p>📍 Estamos en San Martín, conocemos la zona y sus necesidades.<br>📞 Escribinos por WhatsApp y te asesoramos al instante.</p><h3>#PodaDeAlturaSanMartin #ServiciosEnAltura #PodaProfesional #MantenimientoDeÁrboles #SanMartinBA #PodaDeÁrboles #PodaSegura #ArboladoUrbano #ServiciosVerdes #TrabajosEnAltura #PodaEmpresarial #PodaParaConsorcios #PodaResponsable #PodaEnAltura</h3>','PUBLISHED',NULL,'2025-07-07 12:56:48','2025-07-07 12:56:48'),
(31,1,5,'Servicio de Corte de Pasto en Canchas de Rugby','servicio-de-corte-de-pasto-en-canchas-de-rugby','Servicio de Corte de Pasto en Canchas de Rugbyl CEC Liceo Militar, un lugar con historia, disciplina y una energía muy especial.','<h2>Servicio de Corte de Pasto en Canchas de Rugby: CEC Liceo Militar</h2><p>Tuvimos el placer de realizar un nuevo trabajo que recordaremos con mucho orgullo: el <strong>servicio de corte de pasto en las canchas de rugby del CEC Liceo Militar</strong>, un lugar con historia, disciplina y una energía muy especial.</p><p>Desde el momento en que llegamos, nos encontramos con un entorno imponente, rodeado de naturaleza y con un campo de rugby que necesitaba una buena puesta a punto para volver a lucir impecable. El clima acompañó, y con el equipo listo, comenzamos una jornada intensa pero muy gratificante.</p><p>El trabajo consistió en <strong>realizar un corte parejo y prolijo en toda la extensión del campo</strong>, cuidando cada detalle para que la cancha quedara limpia, pareja y con ese aspecto verde uniforme que tanto caracteriza a las buenas superficies deportivas.</p><p>A medida que avanzábamos, se podía ver la transformación del lugar: el pasto recuperaba su color, la superficie se veía más ordenada, y el campo empezaba a reflejar el espíritu del rugby, donde el esfuerzo y la dedicación se notan en cada detalle.</p><p>Lo mejor de todo fue la buena predisposición y el recibimiento de las personas del <strong>CEC Liceo Militar</strong>, que nos abrieron las puertas con amabilidad y confianza. Trabajar en un ambiente así hace que cada tarea sea mucho más que un simple servicio; se convierte en una experiencia compartida.</p><p>Nos sentimos muy agradecidos por haber formado parte del mantenimiento de un espacio tan importante, donde cada fin de semana se viven grandes momentos deportivos y donde el césped es protagonista.</p><p>A todo el equipo del <strong>CEC Liceo Militar</strong>, ¡muchas gracias por su hospitalidad y por permitirnos colaborar en el cuidado de su cancha de rugby!</p><p>📍 Realizamos servicios de corte y mantenimiento de pasto en clubes, predios y espacios deportivos de toda la provincia de Buenos Aires.<br>📲 Consultanos por WhatsApp para más información o presupuesto sin compromiso.</p><h3>#CorteDePasto #CanchasDeRugby #CECLiceoMilitar #MantenimientoDeCampos #PastoVerde #TrabajoEnEquipo #RugbyArgentina #CampoDeJuego #ClientesFelices #MantenimientoProfesional #CorteDeCésped</h3>','PUBLISHED',NULL,'2025-10-05 20:47:42','2025-10-05 20:57:20'),
(32,1,2,'Servicio de Desmalezado y Limpieza de Terrenos en Villa Urquiza – CABA – Buenos Aires: Caso Ivana','servicio-de-desmalezado-y-limpieza-de-terrenos-en-villa-urquiza-caba-buenos-aires-caso-ivana','Desarrollamos un servicio integral de desmalezado y limpieza para el terreno de Ivana en Villa Urquiza.\r\nAnalizamos previamente el estado general del predio y su entorno.\r\nDetectamos acumulación de malezas y vegetación densa.\r\nAplicamos desmalezado mecánico para mayor eficiencia.','<p><strong>Servicio de Desmalezado y Limpieza de Terrenos en Villa Urquiza – CABA – Buenos Aires: Caso Ivana</strong></p><p>Desarrollamos un servicio integral de desmalezado y limpieza para el terreno de Ivana en Villa Urquiza.<br>Analizamos previamente el estado general del predio y su entorno.<br>Detectamos acumulación de malezas y vegetación densa.<br>Aplicamos desmalezado mecánico para mayor eficiencia.<br>Complementamos con tareas manuales en sectores específicos.<br>Retiramos restos vegetales y residuos presentes en el terreno.<br>Mejoramos notablemente la visibilidad y el orden del espacio.<br>El trabajo permitió recuperar la funcionalidad del predio.<br>Se priorizó la seguridad durante toda la ejecución.<br>Utilizamos equipamiento adecuado para zonas urbanas.<br>Respetamos las normativas vigentes de la Ciudad de Buenos Aires.<br>Optimizamos tiempos sin descuidar la calidad del resultado.<br>La limpieza dejó el terreno listo para su próximo uso.<br>Se logró una reducción significativa de riesgos sanitarios.<br>El predio quedó libre de malezas altas y acumulaciones.<br>Aseguramos un acabado prolijo y uniforme.<br>Planificamos cada etapa antes de comenzar el trabajo.<br>Mantenemos comunicación constante con la clienta.<br>Atendimos requerimientos específicos del caso Ivana.<br>Adaptamos el servicio a las dimensiones del terreno.<br>Realizamos un control final para verificar resultados.<br>Nuestra experiencia permitió una ejecución eficiente.<br>El servicio incluyó orden y retiro de desechos verdes.<br>Prestamos atención a cada detalle del proceso.<br>Trabajamos con responsabilidad y compromiso profesional.<br>Conocemos las particularidades de los terrenos en Villa Urquiza.<br>Ofrecemos servicios similares en barrios cercanos de CABA.<br>Atendemos también zonas aledañas según necesidad del cliente.<br>Brindamos soluciones prácticas para terrenos urbanos.<br>El resultado final fue un espacio limpio y despejado.<br>El trabajo facilitó futuros proyectos en el terreno.<br>Priorizamos siempre la satisfacción del cliente.<br>Somos una opción confiable para desmalezado y limpieza.<br>Garantizamos trabajos eficientes y bien ejecutados.<br>Contactanos para evaluar tu caso y comenzar el servicio.</p><p>#CasoIvana #DesmalezadoUrbano #LimpiezaDeLotes #VillaUrquizaCABA #ServiciosDeDesmalezado #TerrenosUrbanos #MantenimientoDePredios #LimpiezaProfesional</p>','PUBLISHED',NULL,'2026-01-11 20:53:10','2026-01-11 21:03:01'),
(33,1,4,'Poda de Altura en Saavedra – CABA – Buenos Aires','poda-de-altura-en-saavedra-caba-buenos-aires','Brindamos servicios profesionales de poda de altura en Saavedra.\r\nTrabajamos en árboles de gran porte dentro de zonas urbanas.\r\nEvaluamos el estado estructural antes de intervenir.\r\nDefinimos el tipo de poda según la necesidad del ejemplar.','<p>&nbsp;Servicio de Poda de Altura en Saavedra – CABA – Buenos Aires</p><p>Brindamos servicios profesionales de poda de altura en Saavedra.<br>Trabajamos en árboles de gran porte dentro de zonas urbanas.<br>Evaluamos el estado estructural antes de intervenir.<br>Definimos el tipo de poda según la necesidad del ejemplar.<br>Aplicamos técnicas que favorecen el crecimiento saludable.<br>Eliminamos ramas secas o peligrosas.<br>Reducimos riesgos para viviendas y peatones.<br>Utilizamos equipos específicos para trabajos en altura.<br>Operamos con personal entrenado y responsable.<br>Respetamos normas de seguridad y prevención.<br>Protegemos el entorno durante cada intervención.<br>Realizamos cortes precisos y controlados.<br>Evitamos daños en estructuras cercanas.<br>Mejoramos la estabilidad y forma del árbol.<br>Optimizamos la entrada de luz natural.<br>Contribuimos a un entorno más seguro y ordenado.<br>Realizamos limpieza posterior al trabajo.<br>Retiramos ramas y restos vegetales.<br>Planificamos cada servicio de manera eficiente.<br>Adaptamos la poda a espacios residenciales y urbanos.<br>Ofrecemos asesoramiento previo al inicio.<br>Respondemos consultas de forma clara.<br>Elaboramos presupuestos detallados.<br>Cumplimos con normativas vigentes en CABA.<br>Prestamos servicios en Saavedra y zonas aledañas.<br>Atendemos barrios cercanos según requerimiento.<br>Trabajamos con compromiso y seriedad.<br>Cuidamos la salud del arbolado urbano.<br>Buscamos resultados duraderos.<br>Mantenemos altos estándares de calidad.<br>Priorizamos la seguridad en cada tarea.<br>Somos una opción confiable en poda de altura.<br>Acompañamos al cliente durante todo el proceso.<br>Garantizamos trabajos responsables y eficientes.<br>Contactanos para coordinar tu servicio de poda.</p><p>#PodaEnAltura #PodaArbolesGrandes #SaavedraBuenosAires #ServicioDePoda #ArboladoUrbano #TrabajosVerticales #MantenimientoVerde #ServiciosEnCABA</p>','PUBLISHED',NULL,'2026-01-11 21:57:35','2026-01-11 22:00:16'),
(34,1,2,'Servicio de Desmalezado y Limpieza de Terrenos en Mataderos – CABA – Buenos Aires','servicio-de-desmalezado-y-limpieza-de-terrenos-en-mataderos-caba-buenos-aires','Brindamos servicios profesionales de desmalezado en Mataderos.\r\nRealizamos limpieza integral de terrenos urbanos y periurbanos.\r\nTrabajamos en lotes baldíos, predios privados y espacios abandonados.\r\nEvaluamos el estado general del terreno antes de intervenir.','<p><strong>Servicio de Desmalezado y Limpieza de Terrenos en Mataderos – CABA – Buenos Aires</strong></p><p>Brindamos servicios profesionales de desmalezado en Mataderos.<br>Realizamos limpieza integral de terrenos urbanos y periurbanos.<br>Trabajamos en lotes baldíos, predios privados y espacios abandonados.<br>Evaluamos el estado general del terreno antes de intervenir.<br>Detectamos malezas, arbustos, residuos y vegetación densa.<br>Definimos el tipo de desmalezado según la superficie y el acceso.<br>Utilizamos herramientas manuales y maquinaria especializada.<br>Aplicamos técnicas seguras y eficientes en cada trabajo.<br>Eliminamos pasto alto y malezas invasivas.<br>Reducimos riesgos sanitarios y presencia de plagas.<br>Prevenimos focos de incendio por acumulación vegetal.<br>Mejoramos la estética y el orden del terreno.<br>Cuidamos estructuras cercanas durante la limpieza.<br>Protegemos veredas, cercos y propiedades linderas.<br>Trabajamos con personal capacitado y responsable.<br>Cumplimos normas de seguridad e higiene laboral.<br>Respetamos la normativa vigente en CABA.<br>Realizamos cortes prolijos y controlados.<br>Retiramos restos verdes y residuos acumulados.<br>Dejamos el terreno despejado y transitable.<br>Ofrecemos servicios para particulares y empresas.<br>Adaptamos el trabajo a terrenos pequeños o grandes extensiones.<br>Planificamos cada servicio de manera eficiente.<br>Optimizamos tiempos y costos operativos.<br>Brindamos asesoramiento previo al inicio del trabajo.<br>Respondemos consultas de forma clara y rápida.<br>Elaboramos presupuestos detallados y transparentes.<br>Atendemos Mataderos y zonas cercanas.<br>Trabajamos con compromiso y seriedad.<br>Buscamos resultados duraderos y efectivos.<br>Mantenemos altos estándares de calidad.<br>Priorizamos la seguridad en cada intervención.<br>Somos una opción confiable en desmalezado.<br>Contactanos para coordinar tu servicio de limpieza.<br>#Desmalezado #LimpiezaDeTerrenos #Mataderos #CABA #ServiciosUrbanos #MantenimientoDeLotes #BuenosAires</p>','PUBLISHED',NULL,'2026-01-13 23:09:55','2026-01-13 23:13:38'),
(35,1,3,'Expertos en Poda de Enredaderas en Buenos Aires','expertos-en-poda-de-enredaderas-en-buenos-aires','Poda de Enredaderas en Buenos Aires: Rápido, Limpio y Seguro\r\n\r\n¿Tu enredadera creció de más y ya es un problema para tu casa?\r\n\r\nRealizamos poda de enredaderas en Buenos Aires con equipo profesional.','<h2>Poda de Enredaderas en Buenos Aires: Rápido, Limpio y Seguro</h2><p>¿Tu enredadera creció de más y ya es un problema para tu casa?</p><p>Realizamos <strong>poda de enredaderas en Buenos Aires</strong> con equipo profesional.</p><p>Despejamos medianeras, techos, cables y canaletas en el acto.</p><p>Evitá humedades y daños estructurales en tus paredes por falta de poda.</p><p>Cortamos <strong>Enamorada del muro</strong>, <strong>Santa Rita</strong>, <strong>Hiedras</strong> y <strong>Jazmines</strong>.</p><p>Servicio técnico especializado en <strong>poda de altura</strong> en CABA y GBA.</p><p>Trabajamos con herramientas desinfectadas para cuidar la salud de tu planta.</p><p>Retiramos todos los residuos verdes: dejamos tu patio o vereda impecable.</p><p>Presupuestos inmediatos: mandanos una foto por WhatsApp ahora mismo.</p><p>Atención personalizada en Palermo, Belgrano, San Isidro y todo GBA.</p><p><strong>Palabras Clave:</strong> Poda de enredaderas, Buenos Aires, CABA, Jardineros.</p><p><strong>Servicio:</strong> Mantenimiento de jardines, Corte de trepadoras, Poda técnica.</p><p><strong>Zonas:</strong> Zona Norte, Zona Oeste, Zona Sur, Capital Federal, San Martín.</p><p><strong>Especies:</strong> Santa Rita, Jazmín de leche, Hiedra común, Ampelopsis.</p><p><strong>Problemas:</strong> Filtraciones, cables enredados, plagas en plantas, humedad.</p><p><strong>Soluciones:</strong> Despeje de tejados, recorte estético, poda de formación.</p><p><strong>Herramientas:</strong> Motosierras de altura, tijerones, escaleras de seguridad.</p><p><strong>Garantía:</strong> Personal con experiencia, puntualidad y limpieza absoluta.</p><p><strong>Disponibilidad:</strong> Turnos programados y servicios de poda urgente.</p><p><strong>Precio:</strong> El mejor costo-beneficio en mantenimiento de exteriores.</p><p>#PodaBuenosAires #JardineriaCABA #PodaDeEnredaderas #GBA #Jardineros.</p><p>#MantenimientoDeCasas #PodaDeAltura #SantaRita #Jardin #BuenosAires.</p><p>#PodaUrgente #CorteDePlantas #Medianeras #Humedad #Hiedra #Limpieza.</p><p>#Jazmin #PaisajismoArgentina #PodaProfesional #CABA #VicenteLopez.</p><p>#SanIsidro #Tigre #RamosMejia #Lanús #Quilmes #LomasDeZamora #Pilar.</p><p>Mantené tu fachada impecable con nuestro servicio de poda controlada.</p><p>No dejes que la vegetación invada la propiedad de tus vecinos.</p><p>Ganá luz natural y seguridad despejando tus ventanas hoy mismo.</p><p>Tu jardín en buenas manos: confianza, rapidez y resultados reales.</p><p><strong>Contacto Directo:</strong> Hacé clic en el botón de WhatsApp y pedí tu turno.</p>','PUBLISHED',NULL,'2026-01-31 18:25:55','2026-01-31 18:30:57'),
(36,1,2,'Desmalezado y Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César','desmalezado-y-limpieza-de-terreno-en-villa-urquiza-caba-buenos-aires-caso-cesar','✅ Cliente: César (Villa Urquiza, Capital Federal)\r\n✅ Problema: Terreno cubierto de maleza alta, escombros y residuos.\r\n✅ Solución: Servicio profesional de limpieza de terrenos y desmalezado.\r\n✅ Resultado: Espacio recuperado, seguro y listo para uso.','<h2>🏆 <strong>Desmalezado y</strong> <strong>Limpieza de Terreno en Villa Urquiza - CABA - Buenos Aires. Caso César</strong></h2><p>✅ <strong>Cliente</strong>: César (Villa Urquiza, Capital Federal)<br>✅ <strong>Problema</strong>: Terreno cubierto de maleza alta, escombros y residuos.<br>✅ <strong>Solución</strong>: Servicio profesional de <strong>limpieza de terrenos y desmalezado</strong>.<br>✅ <strong>Resultado</strong>: Espacio recuperado, seguro y listo para uso.</p><p><br>limpieza de terreno Villa Urquiza</p><p>desmalezado CABA</p><p>limpieza de lotes Buenos Aires</p><p>servicio de desmalezado profesional</p><p>limpieza de terrenos Capital Federal</p><p>poda y retiro de escombros</p><p>mantenimiento de espacios verdes</p><p>desmalezado urgente Villa Urquiza</p><p>&nbsp;</p><h3>📝 <strong>Descripción del servicio realizado</strong>:</h3><p><strong>Inspección inicial</strong> – Evaluación del terreno y plan de trabajo.</p><p><strong>Desmalezado completo</strong> – Corte de maleza, yuyales y pasto alto.</p><p><strong>Recolección de escombros</strong> – Retiro de residuos, cascotes y materiales acumulados.</p><p><strong>Poda de árboles y arbustos</strong> – Formación y saneamiento de vegetación.</p><p><strong>Limpieza final</strong> – Barrido, embolsado y disposición responsable de residuos.</p><p><strong>Recomendaciones post-servicio</strong> – Consejos para mantener el terreno limpio.</p><p>&nbsp;</p><h3>✅ <strong>Beneficios obtenidos por el cliente</strong>:</h3><p>Terreno <strong>seguro y ordenado</strong></p><p>Prevención de plagas e incendios</p><p>Mejora estética y de valor del predio</p><p>Trabajo <strong>rápido y con herramientas profesionales</strong></p><p>Atención personalizada y presupuesto sin cargo</p><h3>🎯 <strong>¿Por qué elegirnos para limpieza de terrenos en CABA?</strong></h3><p>Experiencia en <strong>Villa Urquiza, Belgrano, Saavedra y barrios aledaños</strong></p><p>Equipo propio con motoguadañas, desmalezadoras y camiones de carga</p><p>Trabajos garantizados – <strong>como el Caso César</strong></p><p>Presupuesto gratis y atención inmediata</p><p>&nbsp;</p><p>📞 <strong>¿Necesitás un servicio similar? Contactanos para presupuesto sin cargo en Villa Urquiza y toda CABA.</strong></p>','PUBLISHED',NULL,'2026-02-02 02:31:21','2026-02-02 02:33:59'),
(37,1,4,'Poda de Seguridad en Altura Saavedra: Eliminamos el Riesgo de un Pino de 12 Metros y un Laurel Peligroso','poda-de-seguridad-en-altura-saavedra-eliminamos-el-riesgo-de-un-pino-de-12-metros-y-un-laurel-peligroso','Poda de Seguridad en Altura Saavedra: Eliminamos el Riesgo de un Pino de 12 Metros y un Laurel Peligroso\r\n\r\n¿Buscás un servicio confiable de poda de seguridad en altura en tu propiedad de Saavedra? Te mostramos una intervención urgente donde eliminamos riesgos inminentes: un pino de 12 metros con ramas inestables sobre cables y un laurel con estructuras débiles y peligrosas.','<p><strong>Poda de Seguridad en Altura Saavedra: Eliminamos el Riesgo de un Pino de 12 Metros y un Laurel Peligroso</strong></p><p>¿Buscás un servicio confiable de <strong>poda de seguridad en altura</strong> en tu propiedad de <strong>Saavedra</strong>? Te mostramos una intervención urgente donde eliminamos riesgos inminentes: <strong>un pino de 12 metros con ramas inestables sobre cables y un laurel con estructuras débiles y peligrosas</strong>.</p><p>Este <strong>pino de gran altura</strong> presentaba un claro <strong>peligro de seguridad</strong>: múltiples ramas secas y quebradizas en su copa alta, junto con otras que presionaban y se entrelazaban con líneas eléctricas, riesgo de caída en tormentas. Nuestro equipo de <strong>especialistas en poda de seguridad</strong>, equipado con arneses, cuerdas y motosierras profesionales, realizó una <strong>poda de emergencia controlada</strong>. El objetivo fue <strong>eliminar de forma prioritaria todas las ramas que representaban una amenaza</strong> para personas, bienes e infraestructura, garantizando la estabilidad del árbol a largo plazo.</p><p>En el mismo trabajo, realizamos una <strong>poda de seguridad correctiva en el laurel</strong>. Identificamos y removimos ramas muertas, enfermas y estructuras con riesgo de fractura (codos débiles, cruces peligrosos), previniendo posibles accidentes y mejorando su salud estructural.</p><p><strong>Nuestro compromiso en cada servicio de poda de seguridad en Saavedra:</strong></p><p><strong>Evaluación de riesgo experta:</strong> Identificamos con precisión las ramas y estructuras que representan un peligro real e inmediato.</p><p><strong>Ejecución segura y urgente:</strong> Actuamos con protocolos estrictos para neutralizar la amenaza de forma controlada, protegiendo a las personas y la propiedad.</p><p><strong>Técnica de cortes seguros:</strong> Realizamos cortes que evitan daños mayores al árbol y preparan su recuperación.</p><p><strong>Limpieza integral urgente:</strong> Retiramos de inmediato todo el material peligroso, dejando el área 100% segura.</p><p>¿Tenés <strong>árboles altos que se han convertido en una amenaza</strong> en Saavedra, Núñez, Villa Urquiza o alrededores? No esperes a un accidente. Confiá en expertos con experiencia en <strong>neutralizar riesgos con pinos, laureles, eucaliptos y árboles peligrosos</strong>.</p><p>⚠️ <strong>Contactanos para una INSPECCIÓN DE SEGURIDAD URGENTE y presupuesto sin cargo.</strong> Priorizamos emergencias.</p><p>&nbsp;</p><p>#PodaDeSeguridad #PodaDeEmergencia #PodaUrgente #ArbolPeligroso #PodaSaavedra #RiesgoArbol #PodadoresDeEmergencia #SeguridadEnAltura #PodaDeRiesgo #CablesYArboles #ProteccionCivil #JardineriaUrgente #BuenosAires #PodasSeguras</p><p>&nbsp;</p><p>Poda de seguridad en altura Saavedra</p><p>Poda urgente de árboles peligrosos</p><p>Ramas sobre cables eléctricos poda</p><p>Eliminar riesgo de caída de árboles</p><p>Emergencia poda de pino alto</p><p>Inspección de seguridad de árboles Saavedra</p><p>Poda de riesgo controlado</p><p>Empresa de poda de emergencia Buenos Aires</p><p>Poda para prevenir accidentes</p><p>Árbol que amenaza casa poda</p><p>Tala de seguridad controlada</p><p>Podador urgente Saavedra</p>','PUBLISHED',NULL,'2026-02-04 12:27:18','2026-02-04 12:33:53'),
(38,1,1,'🌿 Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires','recuperacion-de-jardin-limpieza-de-enredaderas-y-cercos-en-beccar-buenos-aires','🌿 Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos 📞 ¿Tu jardín necesita una transformación?\r\nContactanos para un presupuesto sin cargo en Beccar y toda Zona Norte. Transformamos espacios verdes! 🌿✨','<h2>🌿 <strong>Recuperación de Jardín: Limpieza de Enredaderas y Cercos en Beccar - Buenos Aires. Caso Juan Carlos</strong></h2><p>✅ <strong>Cliente</strong>: Juan Carlos (Beccar, Zona Norte, Buenos Aires)<br>✅ <strong>Problema</strong>: Jardín invadido por enredaderas silvestres, cercos cubiertos y vegetación descontrolada.<br>✅ <strong>Solución</strong>: Servicio profesional de <strong>limpieza de jardín, poda de cercos y eliminación de enredaderas</strong>.<br>✅ <strong>Resultado</strong>: Jardín recuperado, ordenado y visualmente renovado.</p><p>&nbsp;</p><h3>📝 <strong>Trabajo realizado para Juan Carlos</strong>:</h3><p><strong>Evaluación inicial</strong> – Diagnóstico del jardín y análisis de las especies invasoras.</p><p><strong>Eliminación de enredaderas</strong> – Extracción manual y controlada de enredaderas que cubrían paredes y árboles.</p><p><strong>Poda completa de cercos</strong> – Formación y nivelación de cercos vivos (ligustros, tuyas, etc.).</p><p><strong>Desmalezado general</strong> – Corte de pasto alto y maleza acumulada en todo el jardín.</p><p><strong>Retiro de ramas y residuos vegetales</strong> – Carga y disposición final responsable.</p><p><strong>Limpieza profunda</strong> – Barrido de hojas, restos de poda y embolsado.</p><p><strong>Recomendaciones finales</strong> – Consejos de mantenimiento para conservar el jardín en óptimas condiciones.</p><h3>✅ <strong>Resultados obtenidos</strong>:</h3><p>🌱 <strong>Jardín completamente renovado</strong> y libre de plagas</p><p>✂️ <strong>Cercos prolijos y definidos</strong> que recuperaron su forma</p><p>🏡 <strong>Espacio exterior más luminoso</strong> y disfrutable</p><p>🌿 <strong>Eliminación total de enredaderas invasoras</strong></p><p>⏱️ <strong>Trabajo rápido</strong> sin afectar la flora útil</p><p>💬 <strong>Cliente 100% satisfecho</strong> – Caso exitoso Juan Carlos</p><h3>🎯 <strong>¿Por qué elegirnos para la recuperación de jardines en Zona Norte?</strong></h3><p>📍 Especialistas en <strong>Beccar, San Isidro, Martínez, Vicente López y toda Zona Norte</strong></p><p>🛠️ <strong>Equipo profesional</strong> con herramientas específicas para cada tarea</p><p>🌳 <strong>Experiencia en jardines complejos</strong> con enredaderas y vegetación densa</p><p>🚛 <strong>Retiro de residuos incluido</strong> en todos los trabajos</p><p>💰 <strong>Presupuesto sin cargo</strong> y asesoramiento personalizado</p><p>⭐ <strong>Trabajos garantizados</strong> como el de Juan Carlos</p><p>📞 <strong>¿Tu jardín necesita una transformación?</strong><br><strong>Contactanos para un presupuesto sin cargo en Beccar y toda Zona Norte. Transformamos espacios verdes!</strong> 🌿✨</p>','PUBLISHED',NULL,'2026-03-05 14:38:37','2026-03-05 14:38:37'),
(39,1,4,'🌲 Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA','tala-controlada-de-2-arboles-de-gran-porte-en-chacarita-caba','🌲 Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA dos árboles de más de 20 metros de altura que habían sido abandonados por completo. Durante años crecieron sin control, desarrollando ramas quebradizas, inclinación peligrosa y una estructura que amenazaba con colapsar sobre la vivienda y los patios.','<h2>🌲 <strong>Tala Controlada de 2 Árboles de Gran Porte en Chacarita – CABA</strong></h2><h3>⚠️ Un peligro latente en el fondo de una casa recién comprada</h3><p>En el corazón de <strong>Chacarita</strong>, un vecino acababa de adquirir una casa con un gran potencial, pero también con un grave problema: <strong>dos árboles de más de 20 metros de altura</strong> que habían sido abandonados por completo. Durante años crecieron sin control, desarrollando ramas quebradizas, inclinación peligrosa y una estructura que amenazaba con colapsar sobre la vivienda y los patios.</p><p>La decisión fue tajante: <strong>había que eliminarlos por completo, cortándolos al ras</strong>, para recuperar la seguridad del hogar y evitar un desastre.</p><p>&nbsp;</p><h3>🧠 Evaluación profesional: diagnóstico preciso</h3><p>Antes de cualquier intervención, se realizó una <strong>inspección técnica detallada</strong> a cargo de un arborista con experiencia en árboles de gran porte. Se analizó:</p><p><strong>Altura exacta y radio de influencia</strong>: superaban los 20 metros, con ramas extendidas sobre el techo de la casa y la medianera.</p><p><strong>Estado estructural</strong>: se detectaron grietas en el tronco principal, madera muerta y hongos en la base de uno de los ejemplares.</p><p><strong>Riesgo de caída</strong>: uno de los árboles presentaba una inclinación crítica que lo hacía extremadamente inestable.</p><p><strong>Logística de trabajo</strong>: se definieron los puntos seguros para el derribo y la extracción, minimizando el impacto en la propiedad.</p><p>Con este diagnóstico, se elaboró un <strong>plan de tala controlada al ras</strong>, priorizando la seguridad en cada paso.</p><p>&nbsp;</p><h3>🪚 Ejecución: tala quirúrgica y extracción total</h3><p>El operativo fue llevado a cabo por un <strong>equipo especializado en tala de árboles de gran tamaño</strong>, utilizando motosierras profesionales, sistemas de amarre, cuerdas de direccionamiento y camión con brazo hidráulico para la carga de troncos. Los pasos fueron:</p><p><strong>Aislamiento del área</strong>: se acordonó la zona de trabajo y se notificó a vecinos para evitar riesgos.</p><p><strong>Aseguramiento de los árboles</strong>: se colocaron cuerdas de anclaje en puntos estratégicos para controlar la dirección de la caída.</p><p><strong>Desrame progresivo</strong>: se eliminaron primero las ramas más pesadas y peligrosas, descendiéndolas con cuerdas para no dañar techos ni instalaciones.</p><p><strong>Derribo del tronco principal</strong>: mediante cortes precisos se hizo caer cada tronco en una dirección segura, lejos de la construcción.</p><p><strong>Corte al ras de tocones</strong>: una vez retirada la estructura principal, se realizó el corte total de los muñones a nivel del suelo, dejando la superficie plana.</p><p><strong>Fragmentación y retiro</strong>: todo el material – ramas, troncos, astillas – fue procesado in situ, cargado en camión y retirado completamente.</p><p><strong>Limpieza profunda</strong>: se barrió el patio, se recogieron restos menores y se dejó el espacio impecable.</p><h3>✅ Resultados: seguridad recuperada y espacio renovado</h3><p>🏡 <strong>Riesgo de caída eliminado al 100 %</strong>, protegiendo la casa y las propiedades linderas.</p><p>🌞 <strong>Amplio patio despejado</strong>, ahora utilizable para jardín, quincho o estacionamiento.</p><p>🚛 <strong>No quedaron rastros de los árboles</strong>: tocones removidos al ras y residuos retirados.</p><p>📜 <strong>Trabajo realizado cumpliendo la normativa vigente de CABA</strong>.</p><p>😊 <strong>El cliente obtuvo la tranquilidad que buscaba para disfrutar su nueva casa</strong>.</p><p>&nbsp;</p><h3>🎯 ¿Por qué confiar en nosotros para talas complejas en Chacarita?</h3><p>🌲 <strong>Especialistas en árboles de más de 20 metros con alto riesgo estructural</strong>.</p><p>🧰 <strong>Personal certificado y equipamiento profesional</strong> (motosierras, cuerdas de seguridad, camión con grúa).</p><p>📍 <strong>Cobertura en Chacarita, Colegiales, Villa Crespo, Palermo y toda la Ciudad</strong>.</p><p>📋 <strong>Presupuesto sin cargo y evaluación técnica previa</strong>.</p><p>🚛 <strong>Retiro de troncos, ramas y tocones incluido en el servicio</strong>.</p><p>⭐ <strong>Experiencia comprobada en operativos de tala controlada en espacios reducidos</strong>.</p><p>&nbsp;</p><h3>📞 ¿Necesitás eliminar árboles peligrosos en tu casa?</h3><p>No esperes a que un árbol se convierta en una emergencia. <strong>Contactanos hoy mismo</strong> y te brindamos una solución profesional, rápida y garantizada.</p><p>&nbsp;</p><h3>&nbsp;</h3><p>tala de árboles Chacarita</p><p>corte de árboles grandes CABA</p><p>extracción de árboles al ras</p><p>eliminar árboles con riesgo de caída</p><p>tala profesional de árboles</p><p>servicio de tala en Capital Federal</p><p>remoción de árboles peligrosos</p><p>tala en patios internos</p><p><br>&nbsp;</p>','PUBLISHED',NULL,'2026-03-26 13:12:06','2026-03-26 13:13:12'),
(40,1,4,'🌳 Servicio de Poda de Altura en Palermo – Buenos Aires','servicio-de-poda-de-altura-en-palermo-buenos-aires','🌳 Servicio de Poda de Altura en Palermo – Buenos Aires - árboles de gran porte que necesitaban una intervención urgente','<h2>🌳 <strong>Servicio de Poda de Altura en Palermo – Buenos Aires</strong></h2><p>&nbsp;</p><h3>🌿 El desafío: árboles de gran porte que necesitaban una intervención urgente</h3><p>Un propietario de una casa en <strong>Palermo, Buenos Aires</strong>, nos contactó con una preocupación que venía creciendo desde hacía meses. En el fondo de su propiedad crecían varios árboles de <strong>envergadura considerable</strong>, que nunca habían recibido mantenimiento profesional.</p><p>Con el paso del tiempo, las ramas más altas comenzaron a extenderse peligrosamente:</p><p>Algunas <strong>sobresalían por encima del techo</strong> de la casa.</p><p>Otras <strong>rozaban los cables del tendido eléctrico</strong>.</p><p>Varias ramas lucían <strong>secas, quebradizas y con riesgo inminente de caída</strong>.</p><p>El clima de Buenos Aires, con tormentas repentinas y ráfagas de viento intensas, convertía a estos árboles en una <strong>amenaza latente</strong> para la vivienda, los vecinos y la seguridad de quienes habitaban la propiedad.</p><p>El cliente necesitaba una <strong>solución profesional, rápida y segura</strong>. No se trataba de una simple poda estética, sino de una <strong>intervención técnica de altura</strong> que requería arboristas especializados.</p><p>&nbsp;</p><h3>🔍 Inspección detallada</h3><p>Antes de cualquier intervención, se realizó una <strong>inspección minuciosa y técnica de cada ejemplar</strong>:</p><p><strong>Altura real</strong>: los árboles superaban ampliamente el nivel del primer piso, alcanzando alturas muy considerables.</p><p><strong>Estado estructural</strong>: se detectaron ramas muertas, otras con grietas profundas y algunas con crecimiento desbalanceado que inclinaba el peso del árbol hacia la vivienda.</p><p><strong>Densidad de copa</strong>: presentaban un follaje extremadamente espeso, que bloqueaba el paso de la luz natural y generaba humedad constante en el patio.</p><p><strong>Proximidad a construcciones</strong>: los árboles estaban ubicados a escasos metros de la casa, de los muros linderos y del tendido eléctrico.</p><p>El diagnóstico fue claro: se necesitaba una <strong>poda de altura selectiva</strong>, eliminando ramas peligrosas, reduciendo la altura de las copas y equilibrando la estructura de cada árbol para garantizar su salud y seguridad.</p><p>&nbsp;</p><h3>🛠️ Intervención profesional paso a paso</h3><p><strong>1. Planificación y medidas de seguridad extremas</strong><br>Se delimitó todo el perímetro de trabajo, se colocaron protecciones en techos y zonas sensibles, y se coordinó con los vecinos para minimizar molestias y garantizar la seguridad de todos.</p><p><strong>2. Acceso con técnicas profesionales</strong><br><strong>Arneses de seguridad, cuerdas estáticas y dinámicas</strong>, y sistemas de ascenso controlado para alcanzar las copas más altas de manera segura.</p><p><strong>3. Desgaje de ramas peligrosas</strong><br>Se procedió a eliminar ramas secas, quebradizas, enfermas o con riesgo de caída inminente. Cada rama fue descendida con cuerdas para evitar golpes a la propiedad, los techos y los muros linderos.</p><p><strong>4. Reducción de altura y equilibrio de copa</strong><br>Se recortaron las puntas más altas de manera controlada y se equilibró la estructura de cada árbol, aliviando el peso de las ramas laterales más largas y pesadas.</p><p><strong>5. Poda de formación y saneamiento</strong><br>Se eliminó madera muerta, ramas entrecruzadas, chupones y brotes débiles, favoreciendo la salud futura de los ejemplares y evitando rebrotes descontrolados.</p><p><strong>6. Fragmentación y retiro total de residuos</strong><br>Todo el material vegetal (ramas grandes, pequeñas, hojas y restos de poda) fue fragmentado, embolsado o cargado en camión, y transportado a centros de disposición final autorizados.</p><p><strong>7.- Entrega y verificación final</strong><br>El cliente recorrió el espacio junto al equipo, confirmando que cada rincón quedó limpio, que los árboles estaban correctamente podados y que el riesgo había sido eliminado por completo.</p><p>&nbsp;</p><h3>✅ Resultados obtenidos</h3><p>🌳 <strong>Árboles podados con técnica profesional</strong>, respetando su biología y fisonomía.</p><p>🏡 <strong>Riesgo de caída totalmente eliminado</strong>: ramas peligrosas retiradas.</p><p>☀️ <strong>Más ingreso de luz natural y menor humedad</strong> en el patio y en el interior de la casa.</p><p>🛡️ <strong>Protección de techos, muros, cables y vecinos</strong> gracias al descenso controlado de ramas.</p><p>🌿 <strong>Mejor salud para los árboles a futuro</strong> gracias a la poda de saneamiento y formación.</p><p>😌 <strong>El cliente recuperó la tranquilidad</strong> y pudo volver a disfrutar de su espacio exterior sin preocupaciones.</p><p>&nbsp;</p><h3>🎯 ¿Por qué elegirnos para poda de altura en Palermo y toda CABA?</h3><p>🧗 <strong>Especialistas en poda de árboles de gran porte</strong> en Palermo, Recoleta, Belgrano, Chacarita, Villa Crespo y todos los barrios de CABA.</p><p>🌳 <strong>Arboristas certificados</strong> con amplia experiencia en arboricultura urbana y trabajos de alta complejidad.</p><p>🛠️ <strong>Equipo profesional completo</strong> con arneses, cuerdas, motosierras de altura, sistemas de descenso y elementos de protección personal.</p><p>📍 <strong>Conocimiento actualizado de la normativa vigente</strong> en CABA para intervenciones en altura y manejo de árboles urbanos.</p><p>🚛 <strong>Retiro de residuos incluido</strong> en todos los trabajos, sin costos ocultos.</p><p>💰 <strong>Presupuesto sin cargo</strong> y asesoramiento técnico personalizado desde la primera consulta.</p><p>⚡ <strong>Respuesta ágil</strong> y coordinación de trabajos en menos de 48 horas.</p><p>&nbsp;</p><h3>📞 ¿Necesitás poda de altura en Palermo o cualquier barrio de la Ciudad?</h3><p>No esperes a que una tormenta o el paso del tiempo conviertan a tus árboles en un peligro real.</p><p><strong>Contactanos hoy mismo para una inspección gratuita y sin compromiso. Dejá tus árboles en manos de verdaderos profesionales!</strong> 🌳🪓</p><p>&nbsp;</p><h3>&nbsp;</h3><p>poda de altura Palermo</p><p>poda de árboles grandes CABA</p><p>servicio de poda profesional Buenos Aires</p><p>arborista en Palermo</p><p>poda de árboles en Capital Federal</p><p>limpieza de copas de árboles</p><p>poda técnica de árboles urbanos</p><p>mantenimiento de árboles de gran porte</p><p>poda con descenso controlado de ramas</p><p>eliminación de ramas con riesgo de caída</p>','PUBLISHED',NULL,'2026-05-25 20:22:56','2026-05-25 20:22:56'),
(41,1,6,'Poda de Altura y Nivelación de Terreno','poda-de-altura-y-nivelacion-de-terreno','Poda de Árbol y Nivelación de Terreno – Servicio Profesional\r\n\r\nEl cliente nos contactó para resolver dos cuestiones puntuales en su propiedad.','<h2>🌳 <strong>Poda de Árbol y Nivelación de Terreno – Servicio Profesional</strong></h2><h3>📍 El caso: un ejemplar de 12 metros y un suelo con desniveles</h3><p>El cliente nos contactó para resolver dos cuestiones puntuales en su propiedad. Por un lado, un <strong>árbol de aproximadamente 12 metros de altura</strong> presentaba ramas secas y un crecimiento que requería intervención. Por otro lado, el terreno evidenciaba <strong>desniveles de hasta 25 cm</strong> en distintas zonas, con acumulación de tierra y restos de obras anteriores que dificultaban el uso del espacio.</p><p>&nbsp;</p><p>&nbsp;</p><h3>🔍 Inspección y diagnóstico</h3><p>Se realizó una visita técnica para evaluar ambas intervenciones:</p><p><strong>Árbol</strong>: ejemplar de 12 metros con ramas secas y otras con grietas. El cliente solicitó que el ejemplar fuera recortado a la altura que él indicó.</p><p><strong>Terreno</strong>: se relevaron desniveles de hasta 25 cm, con pozos y montículos distribuidos en el jardín.</p><p>El plan de trabajo consistió en <strong>realizar primero la poda del árbol, respetando la altura indicada por el cliente, y luego proceder con la nivelación del suelo</strong>.</p><p>&nbsp;</p><p>&nbsp;</p><h3>🛠️ Trabajos realizados</h3><p><strong>Poda del ejemplar:</strong></p><p>Acceso a la copa con arneses y cuerdas de seguridad.</p><p>Eliminación de ramas secas y con riesgo de caída.</p><p>Recorte del árbol hasta la altura solicitada por el cliente.</p><p>Descenso controlado de cada rama para evitar daños a techos y muros.</p><p>Retiro de todos los residuos vegetales.</p><p><strong>Nivelación del terreno:</strong></p><p>Remoción de escombros y piedras enterradas.</p><p>Relleno de pozos con tierra seleccionada.</p><p>Compactación manual para asentar el suelo.</p><p>Perfilado final para dejar una superficie uniforme.</p><p>&nbsp;</p><p>&nbsp;</p><h3>✅ Resultados</h3><p>Árbol podado a la altura indicada por el cliente, sin riesgos y con estructura controlada.</p><p>Terreno nivelado, sin desniveles ni encharcamientos.</p><p>Espacio exterior recuperado para su uso cotidiano.</p><p>Cliente conforme con los resultados obtenidos.</p><p>&nbsp;</p><p>&nbsp;</p><p>poda de árboles, nivelación de terreno, poda de altura, arborista, nivelación de suelo, servicio profesional Buenos Aires, poda con descenso controlado, limpieza de terrenos, mantenimiento de jardines.</p>','PUBLISHED',NULL,'2026-07-07 14:42:28','2026-07-07 14:48:14'),
(42,1,4,'Servicio de Poda de Árboles en Buenos Aires','servicio-de-poda-de-arboles-en-buenos-aires','🌲 Servicio de Poda de Árboles en Buenos Aires – Intervención Profesional\r\n\r\n\r\n\r\n📍 El caso: dos ejemplares, dos trabajos específicos\r\n\r\nEl cliente nos contactó para realizar la poda de dos árboles en su propiedad. Se trataba de un pino de aproximadamente 15 metros de altura y un álamo que requería una intervención más compleja.','<h2>🌲 <strong>Servicio de Poda de Árboles en Buenos Aires – Intervención Profesional</strong></h2><p>&nbsp;</p><h3>📍 El caso: dos ejemplares, dos trabajos específicos</h3><p>El cliente nos contactó para realizar la poda de dos árboles en su propiedad. Se trataba de un <strong>pino de entre 12 y 15 metros de altura</strong> y un <strong>álamo</strong> que requería una intervención más compleja.</p><p>&nbsp;</p><h3>🔍 Inspección y diagnóstico</h3><p>Se realizó una visita técnica para evaluar cada ejemplar y acordar los alcances del trabajo:</p><p><strong>Pino</strong>: ejemplar de 12 a 15 metros. El cliente indicó que debían cortarse todas las ramas, respetando la altura y forma que él definió durante la visita.</p><p><strong>Álamo</strong>: se determinó su corte total al ras del suelo, incluyendo la extracción de raíces que se extendían hacia la galería. El cliente solicitó el retiro completo del ejemplar.</p><p>&nbsp;</p><h3>🛠️ Trabajos realizados</h3><p><strong>Poda del pino:</strong></p><p>Acceso a la copa con arneses y cuerdas de seguridad.</p><p>Corte de todas las ramas según lo indicado por el cliente en la visita.</p><p>Descenso controlado de cada rama para evitar daños a techos, muros y construcciones linderas.</p><p>Las ramas fueron depositadas en la vereda, tal como se acordó previamente.</p><p><strong>Corte y extracción del álamo:</strong></p><p>Corte del tronco al ras del suelo.</p><p>Extracción de raíces que se dirigían hacia la galería, para evitar futuros problemas estructurales.</p><p>Retiro completo del ejemplar, incluyendo tronco, ramas y restos vegetales.</p><p><strong>Personal y seguridad:</strong></p><p>Trabajo realizado por podador experto.</p><p>Personal asegurado contra riesgos laborales.</p><p>Se utilizaron elementos de protección personal y técnicas de descenso controlado.</p><p>&nbsp;</p><h3>✅ Resultados</h3><p>Pino podado según las indicaciones del cliente, con estructura controlada y sin ramas peligrosas.</p><p>Álamo eliminado por completo, sin raíces que afecten la galería.</p><p>Espacio exterior recuperado y ordenado.</p><p>Cliente conforme con la ejecución del trabajo.</p><h3>&nbsp;</h3><p>poda de árboles, poda de pinos, poda de álamos, corte de árboles, extracción de raíces, poda profesional Buenos Aires, poda con descenso controlado, arborista, personal asegurado, podador experto, retiro de árboles, limpieza de terrenos.</p>','PUBLISHED',NULL,'2026-07-08 19:57:09','2026-07-08 20:05:04');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES
(1,'Corte de Pasto','corte-de-pasto','2022-10-25 05:11:14','2022-10-25 05:11:14'),
(2,'Corte de Césped','corte-de-cesped','2022-10-25 05:11:35','2022-10-25 05:11:35'),
(3,'Jardinería','jardineria','2023-02-10 14:49:06','2023-02-10 14:49:06'),
(4,'Mantenimiento de Jardines','mantenimiento-de-jardines','2023-02-10 14:49:20','2023-02-10 14:49:20'),
(5,'Desmalezado','desmalezado','2023-02-22 05:32:44','2023-02-22 05:32:44'),
(6,'Corte de Cercos','corte-de-cercos','2023-04-03 18:41:01','2023-04-03 18:41:22'),
(7,'Poda de Enredaderas','poda-de-enredaderas','2023-04-03 18:41:38','2023-04-03 18:41:38'),
(8,'Poda de Altura','poda-de-altura','2023-10-08 05:23:46','2023-10-08 05:23:46'),
(9,'Corte de Pasto Con Tractor','corte-de-pasto-con-tractor','2025-06-18 15:28:23','2025-06-18 15:28:23'),
(10,'Desmalezado en Mataderos','desmalezado-en-mataderos','2026-01-13 10:27:25','2026-01-13 10:27:25'),
(11,'Poda de seguridad en altura Saavedra','poda-de-seguridad-en-altura-saavedra','2026-02-04 12:29:29','2026-02-04 12:29:29'),
(12,'Poda urgente de árboles peligrosos','poda-urgente-de-arboles-peligrosos','2026-02-04 12:29:46','2026-02-04 12:29:46'),
(13,'Ramas sobre cables eléctricos poda','ramas-sobre-cables-electricos-poda','2026-02-04 12:29:58','2026-02-04 12:29:58'),
(14,'Eliminar riesgo de caída de árboles','eliminar-riesgo-de-caida-de-arboles','2026-02-04 12:30:08','2026-02-04 12:30:08'),
(15,'Emergencia poda de pino alto','emergencia-poda-de-pino-alto','2026-02-04 12:30:22','2026-02-04 12:30:22'),
(16,'Inspección de seguridad de árboles Saavedra','inspeccion-de-seguridad-de-arboles-saavedra','2026-02-04 12:30:34','2026-02-04 12:30:34'),
(17,'Poda de riesgo controlado','poda-de-riesgo-controlado','2026-02-04 12:30:48','2026-02-04 12:30:48'),
(18,'Empresa de poda de emergencia Buenos Aires','empresa-de-poda-de-emergencia-buenos-aires','2026-02-04 12:30:58','2026-02-04 12:30:58'),
(19,'Poda para prevenir accidentes','poda-para-prevenir-accidentes','2026-02-04 12:31:08','2026-02-04 12:31:08'),
(20,'Árbol que amenaza casa poda','arbol-que-amenaza-casa-poda','2026-02-04 12:31:18','2026-02-04 12:31:18'),
(21,'Tala de seguridad controlada','tala-de-seguridad-controlada','2026-02-04 12:31:32','2026-02-04 12:31:32'),
(22,'Podador urgente Saavedra','podador-urgente-saavedra','2026-02-04 12:31:42','2026-02-04 12:31:42'),
(23,'Poda de Altura Buenos Aires','poda-de-altura-buenos-aires','2026-07-08 19:57:34','2026-07-08 19:57:34');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'jofret','jofret_@hotmail.com',NULL,'$2y$10$.PmFu1cZcznh5Q8In7E2Z.1gXTWrwnvTOqpVud5NH6UvMYBoB3qv.','QVR77MTfgrKzcfw9iAKiXwUCAL8OmNvO8p0rqgnWX0lqKzNWeqdPLgJIJPyQ','2022-10-24 06:53:35','2022-10-24 06:53:35'),
(2,'adminxps','budaklzcrew@gmail.com',NULL,'$2y$10$7nR5DU6mrq2FF1f1LLsP3uEijn0PBnbDKvEVA.MusuuxRbIInsZRG',NULL,'2026-01-11 09:20:38','2026-01-11 09:20:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-07-16  2:58:14
